#define MyAppName "Zoltraak Control"
#define MyAppVersion "1.0"
#define MyAppPublisher "PedroZoltraak"
#define MyAppExeName "Zoltraak Control.exe"

[Setup]
AppId={{F70D5059-223B-449B-94D0-85FFCD9A156C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Zoltraak Control
DefaultGroupName=Zoltraak Control
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=installer
OutputBaseFilename=Zoltraak-Control-Setup-v1.0
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=assets\zoltraak.ico
UninstallDisplayName=Zoltraak Control
UninstallDisplayIcon={app}\Zoltraak Control.exe

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Zoltraak Control"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Zoltraak Control"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; GroupDescription: "Atalhos:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Abrir Zoltraak Control"; Flags: nowait postinstall skipifsilent
