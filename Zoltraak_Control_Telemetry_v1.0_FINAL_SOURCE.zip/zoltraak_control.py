import sys
import os
import json
import threading
import time
import ctypes
import base64
import urllib.request
import urllib.error
import webbrowser
import re
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, Signal, QRectF, QPointF, QPoint, QObject, QPropertyAnimation, QEasingCurve, QSequentialAnimationGroup, QPauseAnimation
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QPainterPath, QShortcut, QKeySequence, QImage, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QSlider, QScrollArea,
    QMessageBox, QStackedWidget, QFileDialog, QDialog, QGraphicsBlurEffect, QGraphicsOpacityEffect
)

import zoltraak_overlay_core as core
from zoltraak_extras import (
    OnboardingDialog, WheelDetectionDialog, WheelCompatibilityDialog,
    ArcControlPreview, detect_wheels_local, match_catalog, WHEEL_CATALOG,
    fetch_remote_profile_catalog, match_remote_profile, install_remote_profile
)

APP_VERSION = "1.0"

# ============================================================
# DISTRIBUTION
# ============================================================
# When the installer is published through GitHub Releases, fill
# these two values. The About page will then show the live total
# number of installer downloads.
GITHUB_OWNER = "PedroZoltraak"
GITHUB_REPO = "Zoltraak-Control"
DOWNLOAD_ASSET_PREFIX = "Zoltraak-Control-Setup"
DOWNLOAD_RELEASES_URL = f"https://github.com/{GITHUB_OWNER}/{GITHUB_REPO}/releases"
DOWNLOAD_RELEASES_API = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases?per_page=100"
DOWNLOAD_LATEST_API = f"https://api.github.com/repos/{GITHUB_OWNER}/{GITHUB_REPO}/releases/latest"

# Notes shown once after installing/updating to this version.
RELEASE_NOTES_VERSION = "1.0-final"
LEGACY_RELEASE_TAGS = {"v3.3", "v3.5"}
WELCOME_MESSAGE_ID = "official-v1.0-onboarding-2"
ONBOARDING_VERSION = "v1.0-publish"
RELEASE_DATE = "28/08/2026"
RELEASE_NOTES = [
    {
        "badge": "NOVO",
        "title": "Primeira configuração guiada",
        "body": "Boas-vindas em cinco etapas, guia de uso, avisos de atualização e bloqueio do Control até a conclusão da introdução.",
        "accent": "#ff4b55",
    },
    {
        "badge": "NOVO",
        "title": "Volante & Perfis",
        "body": "Detecção local pelo Windows, solicitação de perfil em poucos segundos e suporte a perfis visuais remotos sem atualizar o programa inteiro.",
        "accent": "#27c7ff",
    },
    {
        "badge": "NOVO",
        "title": "Presets rápidos corrigidos",
        "body": "Completo usa todos os módulos; Compacto remove volante, combustível e DRS; Minimalista mantém apenas T/B/ERS e informações, sem DRS.",
        "accent": "#35df7d",
    },
    {
        "badge": "MELHORADO",
        "title": "Atualizações mais claras",
        "body": "Nova área de Atualizações, verificação manual sempre disponível e notas estruturadas para cada versão.",
        "accent": "#9a7cff",
    },
    {
        "badge": "MELHORADO",
        "title": "Interface mais fluida",
        "body": "Transições discretas e controles para reduzir animações ou desativar efeitos decorativos.",
        "accent": "#ffb454",
    },
    {
        "badge": "CORRIGIDO",
        "title": "Fluxo de primeira abertura",
        "body": "Onboarding, novidades e detecção agora seguem uma sequência única e não se repetem em todas as aberturas.",
        "accent": "#7ee6a8",
    },
    {
        "badge": "NOVO",
        "title": "Modo Arco funcional",
        "body": "A overlay real agora pode ser curvada para acompanhar visualmente o halo, com intensidade ajustável e presets Suave, Médio e Forte.",
        "accent": "#f27cff",
    },
    {
        "badge": "NOVO",
        "title": "Alerta de aproximação do DRS",
        "body": "Nos 100 metros anteriores à ativação, LEDs percorrem os ombros da overlay em direção ao centro e confirmam o ponto exato de abertura.",
        "accent": "#48ef8c",
    },
    {
        "badge": "MELHORADO",
        "title": "Entrada e saída cinematográfica",
        "body": "A overlay agora abre e fecha suavemente a partir do centro, em um movimento inspirado em um livro abrindo e fechando.",
        "accent": "#8f7cff",
    },
    {
        "badge": "NOVO",
        "title": "Tickets diretos e perfis remotos",
        "body": "Solicitações de volante agora chegam diretamente ao suporte sem login no GitHub. Perfis aprovados podem ser baixados pelo catálogo online sem reinstalar o Control.",
        "accent": "#38d98a",
    },
    {
        "badge": "MELHORADO",
        "title": "Ativação e previews refinados",
        "body": "Previews ficam centralizados e limitados aos cartões, o estado UDP ficou mais claro e a telemetria confirma ativação em verde e desativação em vermelho no canto inferior direito.",
        "accent": "#4ee7a8",
    },
]



def version_key(value):
    numbers = re.findall(r"\d+", str(value))
    if not numbers:
        return (0,)
    return tuple(int(n) for n in numbers)


def format_tag(tag):
    text = str(tag or "").strip()
    if not text:
        return "—"
    return text if text.lower().startswith("v") else f"v{text}"


def is_download_asset(name):
    lowered = str(name or "").lower()
    if not lowered:
        return False
    prefix = DOWNLOAD_ASSET_PREFIX.lower()
    return prefix in lowered and (lowered.endswith(".exe") or lowered.endswith(".zip") or lowered.endswith(".msi"))


DEFAULTS = {
    "overlay_enabled": False,
    "scale": 1.0,
    "width_factor": 1.0,
    "height_factor": 1.0,
    "opacity": 1.0,
    "history_seconds": 3.2,
    "history_style": "classic",
    "show_history": True,
    "show_bars": True,
    "show_wheel": True,
    "show_info": True,
    "show_fuel": True,
    "show_active_aero": True,
    "always_on_top": True,
    "lock_position": False,
    "auto_activate_on_connect": False,
    "arc_mode": False,
    "arc_intensity": 0.50,
    "wheel_profile": "default",
    "wheel_profile_name": "Volante padrão Zoltraak",
    "wheel_profile_path": "",
    "wheel_profile_width": 96.0,
    "wheel_profile_offset_x": 0.0,
    "wheel_profile_offset_y": 0.0,
    "wheel_profile_steering_degrees": 360.0,
    "wheel_device_name": "",
    "reduce_animations": False,
    "decorative_effects": True,
    "preset_name": "custom",
    "pos_x": 30,
    "pos_y": 30,
}


def settings_path():
    root = os.getenv("APPDATA")
    if root:
        folder = Path(root) / "ZoltraakControl"
    else:
        folder = Path.home() / ".zoltraak_control"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "settings.json"



def app_state_path():
    root = os.getenv("APPDATA")
    if root:
        folder = Path(root) / "ZoltraakControl"
    else:
        folder = Path.home() / ".zoltraak_control"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "app_state.json"


def load_app_state():
    state = {"last_seen_release_notes": "", "welcome_message_seen": "", "onboarding_seen": "", "wheel_assistant_seen": "", "detected_wheel_name": ""}
    try:
        p = app_state_path()
        if p.exists():
            loaded = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                state.update(loaded)
    except Exception:
        pass
    return state


def save_app_state(state):
    try:
        app_state_path().write_text(
            json.dumps(state, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
    except Exception:
        pass


def resource_path(relative_path):
    """Resolve bundled PyInstaller resources and normal source files."""
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative_path


def load_settings():
    data = dict(DEFAULTS)
    try:
        p = settings_path()
        if p.exists():
            loaded = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                data.update(loaded)
    except Exception:
        pass
    return data


def save_settings(data):
    try:
        settings_path().write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
    except Exception:
        pass


class GlobalHotkeyBridge(QObject):
    triggered = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._started = False

    def start(self):
        if self._started or sys.platform != "win32":
            return
        self._started = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        # Windows global F7 hotkey using only the standard library.
        user32 = ctypes.windll.user32
        hotkey_id = 0x5A17
        VK_F7 = 0x76
        WM_HOTKEY = 0x0312

        class POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        class MSG(ctypes.Structure):
            _fields_ = [
                ("hwnd", ctypes.c_void_p),
                ("message", ctypes.c_uint),
                ("wParam", ctypes.c_size_t),
                ("lParam", ctypes.c_ssize_t),
                ("time", ctypes.c_uint),
                ("pt", POINT),
            ]

        if not user32.RegisterHotKey(None, hotkey_id, 0, VK_F7):
            return

        msg = MSG()
        try:
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_HOTKEY and msg.wParam == hotkey_id:
                    self.triggered.emit()
        finally:
            user32.UnregisterHotKey(None, hotkey_id)


class OverlayPreview(QWidget):
    """Compact preview using the real overlay wheel asset."""

    def __init__(self, parent=None, mini=False):
        super().__init__(parent)
        self._settings = dict(DEFAULTS)
        self._mini = bool(mini)
        self.setMinimumHeight(82 if self._mini else 126)
        self.setObjectName("overlayPreview")

        try:
            raw = base64.b64decode(core.WHEEL_GEMINI_B64)
            self._wheel_image = QImage.fromData(raw, "PNG")
        except Exception:
            self._wheel_image = QImage()

    def setSettings(self, settings):
        self._settings = dict(settings)
        profile_path = str(self._settings.get("wheel_profile_path", "") or "")
        if profile_path and Path(profile_path).exists():
            img = QImage(profile_path)
            if not img.isNull():
                self._wheel_image = img
        elif self._settings.get("wheel_profile", "default") == "default":
            try:
                raw = base64.b64decode(core.WHEEL_GEMINI_B64)
                self._wheel_image = QImage.fromData(raw, "PNG")
            except Exception:
                pass
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)

        r = self.rect().adjusted(8, 10, -8, -10)
        p.setPen(QPen(QColor("#30343a"), 1))
        p.setBrush(QColor("#0b0f14"))
        p.drawRoundedRect(r, 4, 4)

        x = r.left() + 11
        y = r.top() + 10
        h = r.height() - 20

        modules = []
        if self._settings.get("show_history", True):
            modules.append(("history", 165))
        if self._settings.get("show_bars", True):
            modules.append(("bars", 62))
        if self._settings.get("show_wheel", True):
            modules.append(("wheel", 72))
        if self._settings.get("show_info", True):
            modules.append(("info", 62))
        if self._settings.get("show_fuel", True):
            modules.append(("fuel", 20))

        base_gap = 7.0
        base_total = sum(w for _, w in modules) + max(0, len(modules)-1) * base_gap
        avail = max(10.0, r.width() - 22.0)

        # Mini cards must always stay inside their frame. The larger preview
        # may grow a little so the composition does not look lost inside a
        # wide card, while still respecting the available bounds.
        max_scale = 1.0 if self._mini else 1.30
        scale = min(max_scale, avail / max(1.0, base_total))
        gap = base_gap * scale
        actual_total = sum(w * scale for _, w in modules) + max(0, len(modules)-1) * gap

        # True horizontal centering for every module combination.
        x = r.center().x() - (actual_total / 2.0)

        for kind, base_w in modules:
            w = base_w * scale

            if kind == "history":
                box = QRectF(x, y + 5, w, h - 10)
                p.setPen(QPen(QColor("#29313a"), 1))
                p.setBrush(QColor("#10151b"))
                p.drawRoundedRect(box, 4, 4)

                style = str(self._settings.get("history_style", "classic") or "classic").lower()
                if style == "site":
                    inner = box.adjusted(7, 7, -7, -11)
                    p.save()
                    clip = QPainterPath()
                    clip.addRoundedRect(box.adjusted(1, 1, -1, -1), 4, 4)
                    p.setClipPath(clip)
                    p.setPen(QPen(QColor(255, 255, 255, 12), 1))
                    gx = inner.left()
                    while gx <= inner.right():
                        p.drawLine(QPointF(gx, inner.top()), QPointF(gx, inner.bottom()))
                        gx += 18
                    gy = inner.top()
                    while gy <= inner.bottom():
                        p.drawLine(QPointF(inner.left(), gy), QPointF(inner.right(), gy))
                        gy += 12

                    # Signature preview: clean representative traces only.
                    # No large filled polygons here — at preview size they made
                    # the graph look like a solid wedge instead of telemetry.
                    th_points = [
                        QPointF(inner.left(), inner.top()+inner.height()*0.22),
                        QPointF(inner.left()+inner.width()*0.18, inner.top()+inner.height()*0.28),
                        QPointF(inner.left()+inner.width()*0.36, inner.top()+inner.height()*0.58),
                        QPointF(inner.left()+inner.width()*0.52, inner.bottom()-1),
                        QPointF(inner.right(), inner.bottom()-1),
                    ]
                    br_points = [
                        QPointF(inner.left(), inner.bottom()-1),
                        QPointF(inner.left()+inner.width()*0.48, inner.bottom()-1),
                        QPointF(inner.left()+inner.width()*0.66, inner.top()+inner.height()*0.18),
                        QPointF(inner.left()+inner.width()*0.82, inner.top()+inner.height()*0.18),
                        QPointF(inner.right(), inner.top()+inner.height()*0.54),
                    ]

                    def build(points):
                        path = QPainterPath()
                        path.moveTo(points[0])
                        for i in range(1, len(points) - 1):
                            cur = points[i]
                            nxt = points[i + 1]
                            mid = QPointF((cur.x() + nxt.x()) * 0.5, (cur.y() + nxt.y()) * 0.5)
                            path.quadTo(cur, mid)
                        path.lineTo(points[-1])
                        return path

                    th_path = build(th_points)
                    br_path = build(br_points)

                    # Very subtle glow + crisp core, matching the real HUD.
                    p.setPen(QPen(QColor(103, 240, 190, 45), 4.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.drawPath(th_path)
                    p.setPen(QPen(QColor("#67f0be"), 1.7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.drawPath(th_path)

                    p.setPen(QPen(QColor(255, 90, 119, 45), 4.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.drawPath(br_path)
                    p.setPen(QPen(QColor("#ff5a77"), 1.7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
                    p.drawPath(br_path)

                    p.setPen(QColor("#536073"))
                    f = p.font(); f.setPointSize(5); f.setBold(True); p.setFont(f)
                    p.drawText(QRectF(inner.left(), box.bottom()-11, inner.width(), 8), Qt.AlignLeft | Qt.AlignVCenter, "INPUT TRACE")
                    p.restore()
                else:
                    p.setPen(QPen(QColor("#00e676"), 1.6, Qt.SolidLine, Qt.RoundCap))
                    p.drawLine(
                        QPointF(box.left()+9, box.center().y()-11),
                        QPointF(box.right()-9, box.center().y()-11)
                    )
                    p.setPen(QPen(QColor("#ff4250"), 1.6, Qt.SolidLine, Qt.RoundCap))
                    p.drawLine(
                        QPointF(box.left()+9, box.center().y()+11),
                        QPointF(box.right()-9, box.center().y()+11)
                    )

            elif kind == "bars":
                bw = max(7, (w-12)/3)
                for i, col in enumerate(("#00e676", "#ff4250", "#29b6f6")):
                    bx = x + i*(bw+6)
                    p.setPen(QPen(QColor("#30363e"), 1))
                    p.setBrush(QColor("#161c23"))
                    p.drawRoundedRect(QRectF(bx, y+16, bw, h-32), 3, 3)
                    p.setBrush(QColor(col))
                    p.setPen(Qt.NoPen)
                    p.drawRoundedRect(
                        QRectF(bx+2, y+h*0.53, bw-4, h*0.26),
                        2, 2
                    )

            elif kind == "wheel":
                if not self._wheel_image.isNull():
                    target_h = h * 0.78
                    aspect = self._wheel_image.width() / max(1, self._wheel_image.height())
                    target_w = min(w, target_h * aspect)
                    target_h = target_w / aspect

                    target = QRectF(
                        x + (w-target_w)/2,
                        y + (h-target_h)/2,
                        target_w,
                        target_h
                    )
                    p.drawImage(
                        target,
                        self._wheel_image,
                        QRectF(
                            0, 0,
                            self._wheel_image.width(),
                            self._wheel_image.height()
                        )
                    )
                else:
                    p.setPen(QPen(QColor("#8b8c92"), 1))
                    p.drawRect(QRectF(x+5, y+15, w-10, h-30))

            elif kind == "info":
                p.setPen(QColor("#f4f4f5"))
                f = p.font()
                f.setBold(True)
                f.setPointSize(15)
                p.setFont(f)
                p.drawText(QRectF(x, y+2, w, h*.50), Qt.AlignCenter, "7")

                f.setPointSize(8)
                p.setFont(f)
                p.drawText(QRectF(x, y+h*.48, w, h*.32), Qt.AlignCenter, "297")

            elif kind == "fuel":
                cx = x + w/2
                p.setPen(QPen(QColor("#ffd62d"), 1))
                p.setBrush(QColor("#302a17"))
                p.drawRoundedRect(QRectF(cx-3, y+14, 6, h-28), 2, 2)
                p.setBrush(QColor("#ffd62d"))
                p.setPen(Qt.NoPen)
                p.drawRoundedRect(QRectF(cx-2, y+h*.47, 4, h*.33), 1, 1)

            x += w + gap

        if self._settings.get("show_active_aero", True):
            cx = r.center().x()
            p.setPen(QPen(QColor("#4ee77c"), 2, Qt.SolidLine, Qt.RoundCap))
            for off in (-23, -15, -7, 7, 15, 23):
                if off < 0:
                    p.drawLine(
                        QPointF(cx+off-2, r.top()+7),
                        QPointF(cx+off+2, r.top()+3)
                    )
                else:
                    p.drawLine(
                        QPointF(cx+off-2, r.top()+3),
                        QPointF(cx+off+2, r.top()+7)
                    )



class ToggleSwitch(QWidget):
    toggled = Signal(bool)

    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self._checked = bool(checked)
        self.setFixedSize(34, 20)
        self.setCursor(Qt.PointingHandCursor)

    def isChecked(self):
        return self._checked

    def setChecked(self, checked, emit=False):
        checked = bool(checked)
        if checked == self._checked:
            return
        self._checked = checked
        self.update()
        if emit:
            self.toggled.emit(checked)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._checked = not self._checked
            self.update()
            self.toggled.emit(self._checked)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)

        track = QColor("#ff454d") if self._checked else QColor("#333337")
        knob = QColor("#f5f5f6")

        p.setPen(Qt.NoPen)
        p.setBrush(track)
        p.drawRoundedRect(QRectF(1, 2, 32, 16), 3, 3)

        x = 18 if self._checked else 3
        p.setBrush(knob)
        p.drawRoundedRect(QRectF(x, 4, 12, 12), 3, 3)


class StatusDot(QWidget):
    def __init__(self, active=False, parent=None):
        super().__init__(parent)
        self.active = active
        self.setFixedSize(9, 9)

    def setActive(self, active):
        active = bool(active)
        if active != self.active:
            self.active = active
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#39e77b") if self.active else QColor("#55565b"))
        p.drawEllipse(QRectF(1, 1, 7, 7))


class SectionCard(QFrame):
    def __init__(self, index, title, subtitle="", parent=None):
        super().__init__(parent)
        self.setObjectName("card")

        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 18, 20, 20)
        self.layout.setSpacing(11)

        header = QHBoxLayout()
        header.setSpacing(8)

        accent = QFrame()
        accent.setObjectName("sectionAccent")
        accent.setFixedSize(3, 18)
        header.addWidget(accent)

        number = QLabel(f"{index:02d}")
        number.setObjectName("sectionNumber")

        name = QLabel(title.upper())
        name.setObjectName("sectionTitle")

        line = QFrame()
        line.setObjectName("sectionLine")
        line.setFixedHeight(1)

        header.addWidget(number)
        header.addWidget(name)
        header.addSpacing(6)
        header.addWidget(line, 1)
        self.layout.addLayout(header)

        if subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("muted")
            self.layout.addWidget(sub)


class SliderRow(QWidget):
    changed = Signal(float)

    def __init__(self, label, minimum, maximum, value, fmt, parent=None):
        super().__init__(parent)
        self.fmt = fmt
        self.factor = 100

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        top = QHBoxLayout()

        name = QLabel(label)
        name.setObjectName("rowLabel")

        self.value_label = QLabel("")
        self.value_label.setObjectName("valueLabel")

        top.addWidget(name)
        top.addStretch()
        top.addWidget(self.value_label)
        lay.addLayout(top)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(
            int(minimum * self.factor),
            int(maximum * self.factor)
        )
        self.slider.setValue(int(value * self.factor))
        self.slider.valueChanged.connect(self._on_value)
        lay.addWidget(self.slider)

        self._refresh(value)

    def _refresh(self, value):
        self.value_label.setText(self.fmt(value))

    def _on_value(self, raw):
        value = raw / self.factor
        self._refresh(value)
        self.changed.emit(value)

    def setValue(self, value):
        self.slider.blockSignals(True)
        self.slider.setValue(int(value * self.factor))
        self.slider.blockSignals(False)
        self._refresh(value)


class ToggleRow(QWidget):
    changed = Signal(bool)

    def __init__(self, title, subtitle, checked=True, parent=None):
        super().__init__(parent)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 8, 0, 8)
        lay.setSpacing(10)

        ttl = QLabel(title)
        ttl.setObjectName("rowLabel")
        ttl.setMinimumWidth(158)

        sub = QLabel(subtitle)
        sub.setObjectName("muted")

        self.toggle = ToggleSwitch(checked)
        self.toggle.toggled.connect(self.changed.emit)

        lay.addWidget(ttl)
        lay.addWidget(sub, 1)
        lay.addWidget(self.toggle, 0, Qt.AlignVCenter)

        self.setObjectName("toggleRow")

    def setChecked(self, checked):
        self.toggle.setChecked(checked)


class SegmentedOptionRow(QWidget):
    changed = Signal(str)

    def __init__(self, title, subtitle, options, value, parent=None):
        super().__init__(parent)
        self._buttons = {}
        self._value = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 8, 0, 8)
        root.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(10)
        ttl = QLabel(title)
        ttl.setObjectName("rowLabel")
        ttl.setMinimumWidth(158)
        sub = QLabel(subtitle)
        sub.setObjectName("muted")
        sub.setWordWrap(True)
        head.addWidget(ttl)
        head.addWidget(sub, 1)
        root.addLayout(head)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        for key, label in options:
            btn = QPushButton(label)
            btn.setObjectName("presetButton")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self.setValue(k, emit=True))
            self._buttons[key] = btn
            buttons.addWidget(btn)
        buttons.addStretch()
        root.addLayout(buttons)
        self.setObjectName("toggleRow")
        self.setValue(value)

    def setValue(self, value, emit=False):
        self._value = value
        for key, btn in self._buttons.items():
            btn.setProperty("selected", key == value)
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        if emit:
            self.changed.emit(value)

    def value(self):
        return self._value


class SidebarNavButton(QPushButton):
    def __init__(self, text="", icon_type="telemetry", status_dot=False, parent=None):
        super().__init__(text, parent)
        self.icon_type = icon_type
        self.status_dot = status_dot
        self._overlay_active = False
        self.setCursor(Qt.PointingHandCursor)

    def setOverlayActive(self, active):
        active = bool(active)
        if active != self._overlay_active:
            self._overlay_active = active
            self.update()

    def paintEvent(self, event):
        super().paintEvent(event)

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)

        selected = bool(self.property("selected"))
        color = QColor("#ff4a52") if selected else QColor("#8b8c92")

        p.setPen(QPen(color, 1.8, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        p.setBrush(Qt.NoBrush)

        cx = 19.0
        cy = self.height() / 2.0

        if self.icon_type == "telemetry":
            path = QPainterPath()
            path.moveTo(cx - 7, cy + 4)
            path.lineTo(cx - 3, cy)
            path.lineTo(cx, cy + 2)
            path.lineTo(cx + 4, cy - 5)
            path.lineTo(cx + 7, cy - 2)
            p.drawPath(path)
            p.drawLine(QPointF(cx - 7, cy + 7), QPointF(cx + 7, cy + 7))

        elif self.icon_type == "guide":
            p.drawRoundedRect(QRectF(cx - 7, cy - 8, 14, 16), 2, 2)
            p.drawLine(QPointF(cx - 3, cy - 3), QPointF(cx + 3, cy - 3))
            p.drawLine(QPointF(cx - 3, cy + 1), QPointF(cx + 3, cy + 1))
            p.drawLine(QPointF(cx - 3, cy + 5), QPointF(cx + 1, cy + 5))

        elif self.icon_type == "about":
            p.drawEllipse(QRectF(cx - 7, cy - 7, 14, 14))
            p.drawPoint(QPointF(cx, cy - 3))
            p.drawLine(QPointF(cx, cy), QPointF(cx, cy + 4))

        elif self.icon_type == "wheel":
            p.drawEllipse(QRectF(cx - 8, cy - 8, 16, 16))
            p.drawEllipse(QRectF(cx - 2, cy - 2, 4, 4))
            p.drawLine(QPointF(cx, cy - 2), QPointF(cx, cy - 7))
            p.drawLine(QPointF(cx - 2, cy + 1), QPointF(cx - 6, cy + 5))
            p.drawLine(QPointF(cx + 2, cy + 1), QPointF(cx + 6, cy + 5))

        elif self.icon_type == "updates":
            p.drawArc(QRectF(cx - 7, cy - 7, 14, 14), 35 * 16, 270 * 16)
            p.drawLine(QPointF(cx + 5, cy - 6), QPointF(cx + 8, cy - 5))
            p.drawLine(QPointF(cx + 8, cy - 5), QPointF(cx + 7, cy - 2))

        elif self.icon_type == "support":
            p.drawArc(QRectF(cx - 7, cy - 7, 14, 14), 25 * 16, 130 * 16)
            p.drawArc(QRectF(cx - 7, cy - 7, 14, 14), 205 * 16, 130 * 16)
            p.drawLine(QPointF(cx - 7, cy), QPointF(cx - 7, cy + 5))
            p.drawLine(QPointF(cx + 7, cy), QPointF(cx + 7, cy + 5))
            p.drawLine(QPointF(cx + 7, cy + 5), QPointF(cx + 3, cy + 7))

        elif self.icon_type == "settings":
            p.drawEllipse(QRectF(cx - 4, cy - 4, 8, 8))
            for dx, dy in ((0,-8),(0,8),(-8,0),(8,0),(-6,-6),(6,-6),(-6,6),(6,6)):
                p.drawLine(
                    QPointF(cx + dx * 0.58, cy + dy * 0.58),
                    QPointF(cx + dx, cy + dy)
                )

        if self.status_dot:
            dx = self.width() - 18
            if self._overlay_active:
                ring = QColor("#215b35")
                fill = QColor("#2fe477")
            else:
                ring = QColor("#3a3b40")
                fill = QColor("#222327")

            p.setPen(QPen(ring, 2))
            p.setBrush(fill)
            p.drawEllipse(QRectF(dx - 5, cy - 5, 10, 10))



class GuideStep(QFrame):
    def __init__(self, number, title, body_lines, parent=None):
        super().__init__(parent)
        self.setObjectName("guideStep")

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(7)

        head = QHBoxLayout()
        badge = QLabel(str(number))
        badge.setObjectName("guideBadge")
        badge.setAlignment(Qt.AlignCenter)
        badge.setFixedSize(24, 24)

        ttl = QLabel(title)
        ttl.setObjectName("guideTitle")

        head.addWidget(badge)
        head.addWidget(ttl)
        head.addStretch()
        lay.addLayout(head)

        for line in body_lines:
            row = QLabel(line)
            row.setObjectName("guideBody")
            row.setWordWrap(True)
            lay.addWidget(row)



class TitleBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("titleBar")
        self.setFixedHeight(32)
        self._drag_offset = None

        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 0, 6, 0)
        lay.setSpacing(3)

        title = QLabel("Zoltraak")
        title.setObjectName("windowTitleLabel")
        version = QLabel(f"v{APP_VERSION}")
        version.setObjectName("windowVersionLabel")

        lay.addWidget(title)
        lay.addWidget(version)
        lay.addStretch()

        minimize = QPushButton("—")
        minimize.setObjectName("titleButton")
        minimize.setFixedSize(34, 27)
        minimize.clicked.connect(lambda: self.window().showMinimized())

        close = QPushButton("×")
        close.setObjectName("closeButton")
        close.setFixedSize(34, 27)
        close.clicked.connect(lambda: self.window().close())

        lay.addWidget(minimize)
        lay.addWidget(close)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_offset = (
                event.globalPosition().toPoint()
                - self.window().frameGeometry().topLeft()
            )
            event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_offset is not None and (event.buttons() & Qt.LeftButton):
            self.window().move(
                event.globalPosition().toPoint() - self._drag_offset
            )
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_offset = None
        event.accept()


class TelemetryScreenToast(QFrame):
    """Minimal non-intrusive telemetry state notification on the active monitor."""

    def __init__(self, screen=None, active=True, reduced_motion=False):
        super().__init__(None)
        self._active = bool(active)
        self._reduced_motion = bool(reduced_motion)
        self.setWindowFlags(
            Qt.Tool
            | Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setFixedSize(218, 60)

        accent = "#35e77d" if self._active else "#ff4055"
        status = "ACTIVATED" if self._active else "DISABLED"

        card = QFrame(self)
        card.setGeometry(0, 0, self.width(), self.height())
        card.setStyleSheet(
            f"QFrame{{background:rgba(9,12,15,244);border:1px solid {accent}55;"
            f"border-radius:9px;}} QLabel{{background:transparent;border:none;}}"
        )

        root = QHBoxLayout(card)
        root.setContentsMargins(15, 9, 16, 9)
        root.setSpacing(12)

        mark = QLabel("Z")
        mark.setAlignment(Qt.AlignCenter)
        mark.setFixedSize(38, 38)
        mark.setStyleSheet(
            f"color:{accent};font-family:'Segoe UI';font-size:29px;font-weight:900;"
        )

        words = QVBoxLayout()
        words.setContentsMargins(0, 0, 0, 0)
        words.setSpacing(0)

        state = QLabel(status)
        state.setStyleSheet(
            f"color:{accent};font-family:'Segoe UI';font-size:12px;font-weight:850;"
            "letter-spacing:1px;"
        )
        label = QLabel("ZOLTRAAK TELEMETRY")
        label.setStyleSheet(
            "color:#7f8992;font-family:'Segoe UI';font-size:9px;font-weight:600;"
        )

        words.addWidget(state)
        words.addWidget(label)
        root.addWidget(mark, 0, Qt.AlignVCenter)
        root.addLayout(words, 1)

        if screen is None:
            screen = QApplication.primaryScreen()
        geo = screen.availableGeometry() if screen is not None else QApplication.primaryScreen().availableGeometry()

        margin = 24
        self._end_pos = QPoint(
            geo.x() + geo.width() - self.width() - margin,
            geo.y() + geo.height() - self.height() - margin,
        )
        # Slide in horizontally from the right; subtle and fast enough not to distract.
        self._start_pos = self._end_pos + QPoint(18, 0)
        self.move(self._end_pos if self._reduced_motion else self._start_pos)
        self.setWindowOpacity(1.0 if self._reduced_motion else 0.0)

    def present(self):
        self.show()
        self.raise_()
        if self._reduced_motion:
            QTimer.singleShot(1800, self.close)
            return

        self._fade_in = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade_in.setDuration(220)
        self._fade_in.setStartValue(0.0)
        self._fade_in.setEndValue(1.0)
        self._fade_in.setEasingCurve(QEasingCurve.OutCubic)

        self._slide_in = QPropertyAnimation(self, b"pos", self)
        self._slide_in.setDuration(300)
        self._slide_in.setStartValue(self._start_pos)
        self._slide_in.setEndValue(self._end_pos)
        self._slide_in.setEasingCurve(QEasingCurve.OutCubic)

        self._fade_in.start()
        self._slide_in.start()
        QTimer.singleShot(2100, self._dismiss)

    def _dismiss(self):
        if self._reduced_motion:
            self.close()
            return

        self._fade_out = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade_out.setDuration(240)
        self._fade_out.setStartValue(1.0)
        self._fade_out.setEndValue(0.0)
        self._fade_out.setEasingCurve(QEasingCurve.InCubic)

        self._slide_out = QPropertyAnimation(self, b"pos", self)
        self._slide_out.setDuration(260)
        self._slide_out.setStartValue(self._end_pos)
        self._slide_out.setEndValue(self._end_pos + QPoint(12, 0))
        self._slide_out.setEasingCurve(QEasingCurve.InCubic)

        self._fade_out.finished.connect(self.close)
        self._fade_out.start()
        self._slide_out.start()


class StartupSplash(QWidget):
    """Fast minimal startup animation for Zoltraak Telemetry Control."""

    finished = Signal()

    def __init__(self):
        super().__init__()

        self.setWindowFlags(
            Qt.SplashScreen |
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(560, 250)
        self.setWindowOpacity(0.0)

        shell = QFrame(self)
        shell.setObjectName("splashShell")
        shell.setGeometry(0, 0, 560, 250)

        lay = QVBoxLayout(shell)
        lay.setContentsMargins(38, 34, 38, 30)
        lay.setSpacing(0)

        self.splash_logo = QLabel()
        self.splash_logo.setObjectName("splashLogo")
        self.splash_logo.setAlignment(Qt.AlignCenter)
        self.splash_logo.setMinimumHeight(86)

        logo_file = resource_path("assets/zoltraak_logo_horizontal.png")
        if logo_file.exists():
            pix = QPixmap(str(logo_file))
            if not pix.isNull():
                pix = pix.scaled(
                    360, 92,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
                self.splash_logo.setPixmap(pix)

        # Fallback if the bundled image cannot be loaded.
        if self.splash_logo.pixmap() is None or self.splash_logo.pixmap().isNull():
            self.splash_logo.setText("ZOLTRAAK CONTROL")

        self.accent_holder = QWidget()
        self.accent_holder.setFixedHeight(18)

        accent_lay = QHBoxLayout(self.accent_holder)
        accent_lay.setContentsMargins(0, 7, 0, 0)
        accent_lay.setSpacing(0)

        accent_lay.addStretch()

        self.accent = QFrame()
        self.accent.setObjectName("splashAccent")
        self.accent.setFixedHeight(3)
        self.accent.setMaximumWidth(0)
        self.accent.setMinimumWidth(0)

        accent_lay.addWidget(self.accent)

        accent_lay.addStretch()

        status = QLabel("INITIALIZING TELEMETRY")
        status.setObjectName("splashStatus")
        status.setAlignment(Qt.AlignCenter)

        lay.addStretch()
        lay.addWidget(self.splash_logo)
        lay.addSpacing(10)
        lay.addWidget(self.accent_holder)
        lay.addSpacing(8)
        lay.addWidget(status)
        lay.addStretch()

        self.setStyleSheet("""
            #splashShell {
                background: #0b0b0d;
                border: 1px solid #2b2b30;
                border-radius: 5px;
            }

            #splashLogo {
                background: transparent;
                border: none;
            }

            #splashAccent {
                background: #ff454d;
                border: none;
                border-radius: 1px;
            }

            #splashStatus {
                color: #5f6066;
                font-family: "Consolas";
                font-size: 9px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)

        self.fade_in = QPropertyAnimation(self, b"windowOpacity")
        self.fade_in.setDuration(230)
        self.fade_in.setStartValue(0.0)
        self.fade_in.setEndValue(1.0)
        self.fade_in.setEasingCurve(QEasingCurve.OutCubic)

        self.line_anim = QPropertyAnimation(self.accent, b"maximumWidth")
        self.line_anim.setDuration(650)
        self.line_anim.setStartValue(0)
        self.line_anim.setEndValue(250)
        self.line_anim.setEasingCurve(QEasingCurve.OutCubic)

        self.fade_out = QPropertyAnimation(self, b"windowOpacity")
        self.fade_out.setDuration(220)
        self.fade_out.setStartValue(1.0)
        self.fade_out.setEndValue(0.0)
        self.fade_out.setEasingCurve(QEasingCurve.InCubic)

        self.sequence = QSequentialAnimationGroup(self)
        self.sequence.addAnimation(self.fade_in)
        self.sequence.addAnimation(self.line_anim)
        self.sequence.addAnimation(QPauseAnimation(260))
        self.sequence.addAnimation(self.fade_out)
        self.sequence.finished.connect(self._done)

    def start(self):
        screen = QApplication.primaryScreen()
        if screen is not None:
            geo = screen.availableGeometry()
            self.move(
                geo.x() + (geo.width() - self.width()) // 2,
                geo.y() + (geo.height() - self.height()) // 2
            )

        self.show()
        self.raise_()
        self.sequence.start()

    def _done(self):
        self.hide()
        self.finished.emit()



class WelcomeProjectDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Bem-vindo · Zoltraak Control Telemetry")
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(760, 650)
        self._drag_offset = None

        root = QFrame(self)
        root.setObjectName("welcomeRoot")
        root.setGeometry(0, 0, self.width(), self.height())

        outer = QVBoxLayout(root)
        outer.setContentsMargins(28, 24, 28, 24)
        outer.setSpacing(14)

        top = QHBoxLayout()
        top.setSpacing(10)

        logo = QLabel()
        logo.setObjectName("welcomeLogo")
        logo.setFixedSize(205, 50)
        logo_file = resource_path("assets/zoltraak_logo_horizontal.png")
        if logo_file.exists():
            pix = QPixmap(str(logo_file))
            if not pix.isNull():
                logo.setPixmap(pix.scaled(
                    205, 50,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                ))

        badge = QLabel("PROJETO PESSOAL · v1.0")
        badge.setObjectName("welcomeBadge")
        badge.setAlignment(Qt.AlignCenter)
        badge.setFixedHeight(30)

        close_btn = QPushButton("×")
        close_btn.setObjectName("welcomeClose")
        close_btn.setFixedSize(32, 32)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.accept)

        top.addWidget(logo)
        top.addStretch()
        top.addWidget(badge)
        top.addWidget(close_btn)
        outer.addLayout(top)

        title = QLabel("Bem-vindo ao Zoltraak Control Telemetry")
        title.setObjectName("welcomeTitle")
        subtitle = QLabel(
            "Antes de começar, quero contar rapidamente o que é este projeto e por que decidi compartilhá-lo."
        )
        subtitle.setObjectName("welcomeSubtitle")
        subtitle.setWordWrap(True)

        outer.addWidget(title)
        outer.addWidget(subtitle)
        outer.addSpacing(2)

        scroll = QScrollArea()
        scroll.setObjectName("welcomeScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        content = QWidget()
        content.setObjectName("welcomeContent")
        content_lay = QVBoxLayout(content)
        content_lay.setContentsMargins(0, 0, 0, 0)
        content_lay.setSpacing(10)

        sections = [
            (
                "SOBRE O PROJETO",
                "Um projeto pessoal que resolvi compartilhar",
                "O Zoltraak Control Telemetry nasceu como um projeto feito principalmente para o meu próprio uso no F1 26. Eu queria uma forma simples de visualizar a telemetria que realmente me interessava durante as corridas e, depois de desenvolver algo que comecei a gostar de usar, decidi disponibilizá-lo para outras pessoas que também queiram testar.",
                "#ff4b55",
            ),
            (
                "POR QUE ELE EXISTE",
                "Uma ferramenta que eu queria há algum tempo",
                "Há bastante tempo eu procurava algo parecido para o F1, mas não encontrava na web exatamente este tipo de overlay de telemetria da forma que eu queria. As opções mais próximas que encontrei normalmente eram soluções pagas. Então resolvi tentar criar a minha própria alternativa, do meu jeito.",
                "#27c7ff",
            ),
            (
                "IMPORTANTE",
                "Isto não é um produto profissional",
                "Este não é um software comercial nem um projeto profissional. É um projeto pessoal, feito no meu tempo livre e compartilhado gratuitamente para quem tiver interesse em experimentar. Por isso, podem existir bugs, limitações, comportamentos inesperados e coisas que ainda precisam ser melhoradas.",
                "#ffb454",
            ),
            (
                "EM DESENVOLVIMENTO",
                "Ainda há muito que quero melhorar",
                "O Zoltraak Control Telemetry continua em desenvolvimento e ainda precisa de diversos ajustes e refinamentos. Com o tempo pretendo corrigir problemas, melhorar a experiência, aperfeiçoar a overlay e adicionar recursos que façam sentido para o projeto.",
                "#9a7cff",
            ),
            (
                "OBRIGADO",
                "Obrigado por instalar meu projeto pessoal",
                "Obrigado por instalar e dar uma oportunidade ao meu projeto pessoal \"Zoltraak Control Telemetry\". Espero que ele seja útil para você também. Se decidir testar, qualquer feedback sobre bugs, melhorias ou ideias será muito bem-vindo. Obrigado por fazer parte desta primeira versão oficial.",
                "#35df7d",
            ),
        ]

        for section_badge, section_title, body, accent_color in sections:
            card = QFrame()
            card.setObjectName("welcomeCard")
            card_lay = QHBoxLayout(card)
            card_lay.setContentsMargins(15, 13, 16, 13)
            card_lay.setSpacing(13)

            accent = QFrame()
            accent.setFixedWidth(4)
            accent.setStyleSheet(
                f"background:{accent_color}; border:none; border-radius:2px;"
            )

            box = QVBoxLayout()
            box.setSpacing(4)

            label = QLabel(section_badge)
            label.setObjectName("welcomeSectionBadge")
            label.setStyleSheet(
                f"color:{accent_color}; font-size:10px; font-weight:800;"
            )

            heading = QLabel(section_title)
            heading.setObjectName("welcomeSectionTitle")

            paragraph = QLabel(body)
            paragraph.setObjectName("welcomeSectionBody")
            paragraph.setWordWrap(True)

            box.addWidget(label)
            box.addWidget(heading)
            box.addWidget(paragraph)

            card_lay.addWidget(accent)
            card_lay.addLayout(box, 1)
            content_lay.addWidget(card)

        content_lay.addStretch()
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)

        bottom = QHBoxLayout()
        hint = QLabel("Esta mensagem aparece apenas uma vez.")
        hint.setObjectName("welcomeHint")

        ok_btn = QPushButton("COMEÇAR")
        ok_btn.setObjectName("welcomeOk")
        ok_btn.setFixedSize(132, 42)
        ok_btn.setCursor(Qt.PointingHandCursor)
        ok_btn.clicked.connect(self.accept)

        bottom.addWidget(hint)
        bottom.addStretch()
        bottom.addWidget(ok_btn)
        outer.addLayout(bottom)

        self.setStyleSheet("""
            #welcomeRoot {
                background: #101012;
                border: 1px solid #34343a;
                border-radius: 7px;
            }
            #welcomeLogo {
                background: transparent;
                border: none;
            }
            #welcomeBadge {
                color: #ff9da3;
                background: #231113;
                border: 1px solid #65272d;
                border-radius: 4px;
                padding: 0 12px;
                font-family: "Consolas";
                font-size: 10px;
                font-weight: 700;
            }
            #welcomeClose {
                color: #8d8e94;
                background: transparent;
                border: none;
                border-radius: 3px;
                font-size: 20px;
            }
            #welcomeClose:hover {
                color: #ffffff;
                background: #242428;
            }
            #welcomeTitle {
                color: #f4f4f6;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 28px;
                font-weight: 750;
            }
            #welcomeSubtitle {
                color: #9b9ca2;
                font-size: 13px;
                font-weight: 450;
            }
            #welcomeScroll,
            #welcomeContent {
                background: transparent;
                border: none;
            }
            #welcomeCard {
                background: #171719;
                border: 1px solid #29292e;
                border-radius: 5px;
            }
            #welcomeSectionTitle {
                color: #eeeeef;
                font-size: 15px;
                font-weight: 700;
            }
            #welcomeSectionBody {
                color: #96979d;
                font-size: 12px;
                font-weight: 450;
            }
            #welcomeHint {
                color: #65666c;
                font-size: 11px;
            }
            #welcomeOk {
                color: #ffffff;
                background: #ff4852;
                border: 1px solid #ff4852;
                border-radius: 4px;
                font-size: 12px;
                font-weight: 800;
            }
            #welcomeOk:hover {
                background: #ff5a63;
                border-color: #ff5a63;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 6px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #37383e;
                min-height: 28px;
                border-radius: 3px;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_offset is not None and (event.buttons() & Qt.LeftButton):
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_offset = None
        super().mouseReleaseEvent(event)


class UpdateNotesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Novidades · v{RELEASE_NOTES_VERSION}")
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(720, 610)
        self._release_card_anims = []
        self._release_cards = []

        root = QFrame(self)
        root.setObjectName("updateNotesRoot")
        root.setGeometry(0, 0, self.width(), self.height())

        outer = QVBoxLayout(root)
        outer.setContentsMargins(26, 22, 26, 22)
        outer.setSpacing(14)

        top = QHBoxLayout()
        top.setSpacing(10)

        logo = QLabel()
        logo.setObjectName("updateNotesLogo")
        logo.setFixedSize(188, 46)
        logo_file = resource_path("assets/zoltraak_logo_horizontal.png")
        if logo_file.exists():
            pix = QPixmap(str(logo_file))
            if not pix.isNull():
                logo.setPixmap(pix.scaled(
                    188, 46,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                ))

        installed = QLabel(f"v{APP_VERSION} · {RELEASE_DATE}")
        installed.setObjectName("updateInstalledBadge")
        installed.setAlignment(Qt.AlignCenter)
        installed.setFixedHeight(28)

        close_btn = QPushButton("×")
        close_btn.setObjectName("updateCloseButton")
        close_btn.setFixedSize(32, 32)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.accept)

        top.addWidget(logo)
        top.addStretch()
        top.addWidget(installed)
        top.addWidget(close_btn)
        outer.addLayout(top)

        title = QLabel(f"Novidades da versão {RELEASE_NOTES_VERSION}")
        title.setObjectName("updateNotesTitle")
        subtitle = QLabel(
            "O Zoltraak Control foi atualizado. Estas são as principais mudanças desta versão."
        )
        subtitle.setObjectName("updateNotesSubtitle")
        subtitle.setWordWrap(True)

        outer.addWidget(title)
        outer.addWidget(subtitle)
        outer.addSpacing(4)

        notes_scroll = QScrollArea()
        notes_scroll.setObjectName("updateNotesScroll")
        notes_scroll.setWidgetResizable(True)
        notes_scroll.setFrameShape(QFrame.NoFrame)
        notes_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        notes_content = QWidget()
        notes_content.setObjectName("updateNotesContent")
        notes_lay = QVBoxLayout(notes_content)
        notes_lay.setContentsMargins(0, 0, 0, 0)
        notes_lay.setSpacing(9)

        for note in RELEASE_NOTES:
            card = QFrame()
            card.setObjectName("releaseNoteCard")
            card_lay = QHBoxLayout(card)
            card_lay.setContentsMargins(14, 12, 15, 12)
            card_lay.setSpacing(12)

            accent = QFrame()
            accent.setFixedWidth(4)
            accent.setStyleSheet(
                f"background:{note['accent']}; border:none; border-radius:2px;"
            )

            note_box = QVBoxLayout()
            note_box.setSpacing(3)

            badge = QLabel(note["badge"])
            badge.setObjectName("releaseNoteBadge")
            badge.setStyleSheet(
                f"color:{note['accent']}; font-size:11px; font-weight:800;"
            )

            note_title = QLabel(note["title"])
            note_title.setObjectName("releaseNoteTitle")

            body = QLabel(note["body"])
            body.setObjectName("releaseNoteBody")
            body.setWordWrap(True)

            note_box.addWidget(badge)
            note_box.addWidget(note_title)
            note_box.addWidget(body)

            card_lay.addWidget(accent)
            card_lay.addLayout(note_box, 1)
            notes_lay.addWidget(card)
            effect = QGraphicsOpacityEffect(card)
            effect.setOpacity(0.0)
            card.setGraphicsEffect(effect)
            self._release_cards.append((card, effect))

        for idx, (card, effect) in enumerate(self._release_cards):
            def start_anim(c=card, e=effect):
                anim = QPropertyAnimation(e, b"opacity", self)
                anim.setDuration(220)
                anim.setStartValue(0.0)
                anim.setEndValue(1.0)
                anim.setEasingCurve(QEasingCurve.OutCubic)
                anim.finished.connect(lambda c=c: c.setGraphicsEffect(None))
                self._release_card_anims.append(anim)
                anim.start()
            QTimer.singleShot(70 + idx * 65, start_anim)

        notes_lay.addStretch()
        notes_scroll.setWidget(notes_content)
        outer.addWidget(notes_scroll, 1)

        bottom = QHBoxLayout()
        hint = QLabel("Esta janela aparece uma vez por versão.")
        hint.setObjectName("updateNotesHint")

        ok_btn = QPushButton("ENTENDI")
        ok_btn.setObjectName("updateNotesOk")
        ok_btn.setFixedSize(122, 40)
        ok_btn.setCursor(Qt.PointingHandCursor)
        ok_btn.clicked.connect(self.accept)

        bottom.addWidget(hint)
        bottom.addStretch()
        bottom.addWidget(ok_btn)
        outer.addLayout(bottom)

        self.setStyleSheet("""
            #updateNotesRoot {
                background: #101012;
                border: 1px solid #34343a;
                border-radius: 7px;
            }
            #updateNotesLogo {
                background: transparent;
                border: none;
            }
            #updateInstalledBadge {
                color: #95f6b4;
                background: #101b14;
                border: 1px solid #245b35;
                border-radius: 4px;
                padding: 0 12px;
                font-family: "Consolas";
                font-size: 10px;
                font-weight: 700;
            }
            #updateCloseButton {
                color: #8d8e94;
                background: transparent;
                border: none;
                border-radius: 3px;
                font-size: 20px;
            }
            #updateCloseButton:hover {
                color: #ffffff;
                background: #242428;
            }
            #updateNotesTitle {
                color: #f4f4f6;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 27px;
                font-weight: 750;
            }
            #updateNotesSubtitle {
                color: #94959b;
                font-size: 13px;
                font-weight: 450;
            }
            #updateNotesScroll,
            #updateNotesContent {
                background: transparent;
                border: none;
            }
            #releaseNoteCard {
                background: #171719;
                border: 1px solid #29292e;
                border-radius: 5px;
            }
            #releaseNoteTitle {
                color: #eeeeef;
                font-size: 15px;
                font-weight: 700;
            }
            #releaseNoteBody {
                color: #929399;
                font-size: 12px;
                font-weight: 450;
            }
            #updateNotesHint {
                color: #65666c;
                font-size: 11px;
            }
            #updateNotesOk {
                color: #ffffff;
                background: #ff4852;
                border: 1px solid #ff4852;
                border-radius: 4px;
                font-size: 12px;
                font-weight: 800;
            }
            #updateNotesOk:hover {
                background: #ff5a63;
                border-color: #ff5a63;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 6px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #37383e;
                min-height: 28px;
                border-radius: 3px;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if hasattr(self, "_drag_offset") and self._drag_offset is not None and (event.buttons() & Qt.LeftButton):
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_offset = None
        super().mouseReleaseEvent(event)


class ControlWindow(QMainWindow):
    download_count_ready = Signal(object)
    latest_release_ready = Signal(object)
    wheel_detection_ready = Signal(object)
    remote_profile_ready = Signal(object)
    def __init__(self):
        super().__init__()

        self.settings = load_settings()
        self.app_state = load_app_state()

        self.overlay = core.Overlay()
        core.HISTORY_SECONDS = float(self.settings["history_seconds"])
        self.overlay.apply_settings(self.settings)

        self._last_pos = (
            self.settings["pos_x"],
            self.settings["pos_y"]
        )

        self.setWindowTitle(f"Zoltraak Control v{APP_VERSION}")
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint)
        self.resize(1140, 780)
        self.setMinimumSize(1040, 700)

        self._build_ui()
        self._apply_style()
        self._load_ui_values()

        self.download_count_ready.connect(self._set_download_count)
        self.latest_release_ready.connect(self._set_latest_release_info)
        self.wheel_detection_ready.connect(self._apply_detected_wheels)
        self.remote_profile_ready.connect(self._apply_remote_profile_result)
        self.latest_release_url = DOWNLOAD_RELEASES_URL
        self.nav_overlay.setProperty("selected", True)
        self.nav_guide.setProperty("selected", False)
        self.nav_about.setProperty("selected", False)
        if hasattr(self, "nav_updates"):
            self.nav_updates.setProperty("selected", False)
        if hasattr(self, "nav_wheels"):
            self.nav_wheels.setProperty("selected", False)
        if hasattr(self, "nav_settings"):
            self.nav_settings.setProperty("selected", False)

        self.move_shortcut = QShortcut(QKeySequence("F6"), self)
        self.move_shortcut.setContext(Qt.ApplicationShortcut)
        self.move_shortcut.activated.connect(self._move_overlay)

        # F7 is a real global Windows hotkey, so it also works while F1 26
        # has focus.
        self.hotkey_bridge = GlobalHotkeyBridge(self)
        self.hotkey_bridge.triggered.connect(self._toggle_overlay)
        self.hotkey_bridge.start()

        self._was_connected = False
        self._test_restore_visible = False
        self._test_running = False
        self._screen_activation_toast = None

        # One UDP receiver owned by the control app.
        threading.Thread(
            target=core.receiver,
            daemon=True
        ).start()

        self.status_timer = QTimer(self)
        self.status_timer.timeout.connect(self._refresh_status)
        self.status_timer.start(350)

        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.timeout.connect(self._save_now)

        # Download statistics. Public GitHub Releases are queried at
        # startup and then every 10 minutes. No token is required.
        self.downloads_timer = QTimer(self)
        self.downloads_timer.timeout.connect(self._refresh_release_data)
        self.downloads_timer.start(10 * 60 * 1000)
        QTimer.singleShot(1000, self._refresh_release_data)

        if self.settings.get("overlay_enabled", False):
            self.overlay.animated_show()
        else:
            self.overlay.hide()

        self._sync_activation_ui()

        # First official launch: complete onboarding -> updates -> wheel detection.
        QTimer.singleShot(850, self._show_startup_messages_if_needed)

    def _exec_dimmed(self, dialog):
        effect = None
        dimmer = None
        try:
            host = self.centralWidget()
            dimmer = QFrame(host)
            dimmer.setStyleSheet("background:rgba(0,0,0,145);border:none;")
            dimmer.setGeometry(host.rect())
            dimmer.show()
            dimmer.raise_()
            effect = QGraphicsBlurEffect(host)
            effect.setBlurRadius(2.2)
            host.setGraphicsEffect(effect)
        except Exception:
            effect = None
        try:
            return dialog.exec()
        finally:
            try:
                self.centralWidget().setGraphicsEffect(None)
            except Exception:
                pass
            if dimmer is not None:
                try:
                    dimmer.hide()
                    dimmer.deleteLater()
                except Exception:
                    pass

    def _show_startup_messages_if_needed(self):
        onboarding_seen = str(self.app_state.get("onboarding_seen", ""))
        first_publish_onboarding = onboarding_seen != ONBOARDING_VERSION

        if first_publish_onboarding:
            dialog = OnboardingDialog(
                APP_VERSION,
                verify_updates_callback=self._refresh_release_data,
                resource_resolver=resource_path,
                parent=self,
            )
            self._exec_dimmed(dialog)
            self.app_state["onboarding_seen"] = ONBOARDING_VERSION
            self.app_state["welcome_message_seen"] = WELCOME_MESSAGE_ID
            save_app_state(self.app_state)

            # The release notes are intentionally shown after the five onboarding pages.
            notes = UpdateNotesDialog(self)
            self._exec_dimmed(notes)
            self.app_state["last_seen_release_notes"] = RELEASE_NOTES_VERSION
            save_app_state(self.app_state)

            # Then begin the one-time wheel assistant while the Control remains blocked.
            self._run_startup_wheel_assistant()
            return

        self._show_release_notes_if_needed()
        self._start_wheel_detection(startup=False)

    def _show_release_notes_if_needed(self):
        seen = str(self.app_state.get("last_seen_release_notes", ""))
        if seen == RELEASE_NOTES_VERSION:
            return
        dialog = UpdateNotesDialog(self)
        self._exec_dimmed(dialog)
        self.app_state["last_seen_release_notes"] = RELEASE_NOTES_VERSION
        save_app_state(self.app_state)

    def _run_startup_wheel_assistant(self):
        if str(self.app_state.get("wheel_assistant_seen", "")) == ONBOARDING_VERSION:
            self._start_wheel_detection(startup=False)
            return
        dialog = WheelDetectionDialog(None, self)
        dialog.choiceMade.connect(self._wheel_assistant_choice)
        self._exec_dimmed(dialog)
        detected = dialog.detected_names[0] if dialog.detected_names else ""
        self.app_state["detected_wheel_name"] = detected
        self.app_state["wheel_assistant_seen"] = ONBOARDING_VERSION
        if detected:
            self.settings["wheel_device_name"] = detected
            self._schedule_save()
        save_app_state(self.app_state)
        self._refresh_wheel_page([detected] if detected else [])

    def _open_release_notes(self):
        dialog = UpdateNotesDialog(self)
        self._exec_dimmed(dialog)

    def _start_wheel_detection(self, startup=False):
        def worker():
            names = detect_wheels_local()
            self.wheel_detection_ready.emit({"names": names, "startup": bool(startup)})
        threading.Thread(target=worker, daemon=True).start()

    def _apply_detected_wheels(self, payload):
        payload = payload if isinstance(payload, dict) else {}
        names = list(payload.get("names") or [])
        startup = bool(payload.get("startup"))
        detected = names[0] if names else ""
        self.app_state["detected_wheel_name"] = detected
        if detected:
            self.settings["wheel_device_name"] = detected
            self._schedule_save()
        save_app_state(self.app_state)
        self._refresh_wheel_page(names)
        if detected:
            self._check_remote_profile(silent=True)

        if startup and str(self.app_state.get("wheel_assistant_seen", "")) != ONBOARDING_VERSION:
            dialog = WheelDetectionDialog(names, self)
            dialog.choiceMade.connect(self._wheel_assistant_choice)
            self._exec_dimmed(dialog)
            self.app_state["wheel_assistant_seen"] = ONBOARDING_VERSION
            save_app_state(self.app_state)
        elif detected:
            # Normal launches only update the saved detection silently.
            pass

    def _wheel_assistant_choice(self, action, device_name):
        self.settings["wheel_device_name"] = device_name or ""
        # A specific visual is only selected after a tested profile exists.
        self.settings["wheel_profile"] = "default"
        self._schedule_save()
        self._refresh_wheel_page([device_name] if device_name else [])
        if device_name:
            QTimer.singleShot(250, lambda: self._show_status_toast(
                "DISPOSITIVO RECONHECIDO",
                f"{device_name} detectado. O volante padrão será usado até existir um perfil visual específico.",
                "#38d98a"
            ))
        else:
            QTimer.singleShot(250, lambda: self._show_status_toast(
                "VOLANTE PADRÃO MANTIDO",
                "Nenhum perfil compatível foi ativado. Você pode alterar essa escolha em Volante & Perfis.",
                "#6aa8ff"
            ))

    def _show_status_toast(self, title, body, accent="#38d98a"):
        host = self.centralWidget()
        toast = QFrame(host)
        toast.setStyleSheet(f"QFrame{{background:#131519;border:1px solid #30343b;border-left:3px solid {accent};border-radius:5px;}} QLabel{{background:transparent;border:none;}}")
        layout = QVBoxLayout(toast); layout.setContentsMargins(14,10,14,10); layout.setSpacing(3)
        ttl = QLabel(title); ttl.setStyleSheet(f"color:{accent};font-size:11px;font-weight:800;")
        txt = QLabel(body); txt.setStyleSheet("color:#c2c5cc;font-size:12px;"); txt.setWordWrap(True)
        layout.addWidget(ttl); layout.addWidget(txt)
        toast.setFixedWidth(390); toast.adjustSize()
        toast.move(max(18, host.width()-toast.width()-24), 48)
        effect = QGraphicsOpacityEffect(toast); toast.setGraphicsEffect(effect); effect.setOpacity(0.0)
        toast.show(); toast.raise_()
        enter = QPropertyAnimation(effect, b"opacity", toast); enter.setDuration(180); enter.setStartValue(0.0); enter.setEndValue(1.0); enter.setEasingCurve(QEasingCurve.OutCubic)
        toast._enter_anim = enter; enter.start()
        def fade_out():
            out = QPropertyAnimation(effect, b"opacity", toast); out.setDuration(220); out.setStartValue(1.0); out.setEndValue(0.0); out.setEasingCurve(QEasingCurve.InCubic); out.finished.connect(toast.deleteLater); toast._out_anim = out; out.start()
        QTimer.singleShot(3200, fade_out)

    def _build_ui(self):
        root = QFrame()
        root.setObjectName("windowFrame")
        self.setCentralWidget(root)

        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        outer.addWidget(TitleBar(self))

        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)
        outer.addWidget(body, 1)

        # ========================================================
        # SIDEBAR
        # ========================================================
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(300)

        side = QVBoxLayout(sidebar)
        side.setContentsMargins(24, 31, 20, 22)
        side.setSpacing(8)

        brand = QHBoxLayout()
        brand.setSpacing(11)

        logo = QLabel("Z")
        logo.setObjectName("logo")
        logo.setFixedWidth(46)
        logo.setAlignment(Qt.AlignCenter)

        brand_info = QVBoxLayout()
        brand_info.setSpacing(1)

        brand_line = QHBoxLayout()
        brand_line.setSpacing(7)

        name = QLabel("Zoltraak")
        name.setObjectName("brand")

        version = QLabel(f"v{APP_VERSION}")
        version.setObjectName("brandVersion")

        brand_line.addWidget(name)
        brand_line.addWidget(version)
        brand_line.addStretch()

        connection_row = QHBoxLayout()
        connection_row.setSpacing(6)
        self.connection_dot = StatusDot(False)
        self.connection_label = QLabel("WAITING FOR F1")
        self.connection_label.setObjectName("connectionWait")
        connection_row.addWidget(self.connection_dot)
        connection_row.addWidget(self.connection_label)
        connection_row.addStretch()

        brand_info.addLayout(brand_line)
        brand_info.addLayout(connection_row)

        brand.addWidget(logo)
        brand.addLayout(brand_info, 1)
        side.addLayout(brand)

        side.addSpacing(17)

        divider = QFrame()
        divider.setObjectName("sideDivider")
        divider.setFixedHeight(1)
        side.addWidget(divider)

        side.addSpacing(16)

        menu_title = QLabel("OVERLAYS")
        menu_title.setObjectName("menuLabel")
        side.addWidget(menu_title)
        side.addSpacing(4)

        nav = SidebarNavButton(
            "Telemetry Overlay",
            icon_type="telemetry",
            status_dot=True
        )
        nav.setObjectName("navActive")
        nav.setFixedHeight(52)
        nav.clicked.connect(lambda: self._show_page("overlay"))
        self.nav_overlay = nav
        side.addWidget(nav)

        guide_nav = SidebarNavButton(
            "Guia de Configuração",
            icon_type="guide"
        )
        guide_nav.setObjectName("navSecondary")
        guide_nav.setFixedHeight(50)
        guide_nav.clicked.connect(lambda: self._show_page("guide"))
        self.nav_guide = guide_nav
        side.addWidget(guide_nav)

        wheels_nav = SidebarNavButton(
            "Volante & Perfis",
            icon_type="wheel"
        )
        wheels_nav.setObjectName("navSecondary")
        wheels_nav.setFixedHeight(50)
        wheels_nav.clicked.connect(lambda: self._show_page("wheels"))
        self.nav_wheels = wheels_nav
        side.addWidget(wheels_nav)

        updates_nav = SidebarNavButton(
            "Atualizações",
            icon_type="updates"
        )
        updates_nav.setObjectName("navSecondary")
        updates_nav.setFixedHeight(50)
        updates_nav.clicked.connect(lambda: self._show_page("updates"))
        self.nav_updates = updates_nav
        side.addWidget(updates_nav)

        about_nav = SidebarNavButton(
            "Sobre",
            icon_type="about"
        )
        about_nav.setObjectName("navSecondary")
        about_nav.setFixedHeight(50)
        about_nav.clicked.connect(lambda: self._show_page("about"))
        self.nav_about = about_nav
        side.addWidget(about_nav)

        side.addStretch()

        support = SidebarNavButton(
            "Discord / Suporte",
            icon_type="support"
        )
        support.setObjectName("sideBottomButton")
        support.setFixedHeight(48)
        support.clicked.connect(self._show_support)
        side.addWidget(support)

        divider2 = QFrame()
        divider2.setObjectName("sideDivider")
        divider2.setFixedHeight(1)
        side.addWidget(divider2)

        settings = SidebarNavButton(
            "Configurações",
            icon_type="settings"
        )
        settings.setObjectName("sideBottomButton")
        settings.setFixedHeight(48)
        settings.clicked.connect(lambda: self._show_page("settings"))
        self.nav_settings = settings
        side.addWidget(settings)

        body_layout.addWidget(sidebar)

        # ========================================================
        # MAIN AREA
        # ========================================================
        scroll = QScrollArea()
        self.content_scroll = scroll
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setObjectName("scroll")

        content = QWidget()
        content.setObjectName("mainContent")

        main = QVBoxLayout(content)
        main.setContentsMargins(48, 34, 48, 40)
        main.setSpacing(15)

        # Header
        header = QHBoxLayout()

        title_box = QVBoxLayout()
        title_box.setSpacing(1)

        eyebrow = QLabel("OVERLAY")
        eyebrow.setObjectName("eyebrow")

        title = QLabel("Telemetry Overlay")
        title.setObjectName("pageTitle")

        subtitle = QLabel(
            "Configure aparência, elementos e comportamento da sua overlay"
        )
        subtitle.setObjectName("pageSubtitle")

        title_box.addWidget(eyebrow)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        header.addLayout(title_box)
        header.addStretch()

        self.activate_btn = QPushButton()
        self.activate_btn.setFixedSize(142, 45)
        self.activate_btn.setCursor(Qt.PointingHandCursor)
        self.activate_btn.clicked.connect(self._toggle_overlay)
        header.addWidget(self.activate_btn, 0, Qt.AlignTop)

        main.addLayout(header)
        main.addSpacing(9)

        # Status strip
        self.status_banner = QFrame()
        self.status_banner.setObjectName("statusBanner")
        self.status_banner.setFixedHeight(52)

        status_layout = QHBoxLayout(self.status_banner)
        status_layout.setContentsMargins(14, 0, 14, 0)

        self.status_text = QLabel()
        self.status_text.setObjectName("statusText")

        self.telemetry_health = QLabel("F1 OFFLINE  ·  UDP -- Hz")
        self.telemetry_health.setObjectName("telemetryHealthWait")

        hint = QLabel("F6  ·  MOVER OVERLAY")
        hint.setObjectName("statusHint")

        status_layout.addWidget(self.status_text)
        status_layout.addStretch()
        status_layout.addWidget(self.telemetry_health)
        status_layout.addSpacing(16)
        status_layout.addWidget(hint)

        main.addWidget(self.status_banner)

        preview_card = QFrame()
        preview_card.setObjectName("previewCard")
        preview_lay = QVBoxLayout(preview_card)
        preview_lay.setContentsMargins(14, 10, 14, 12)
        preview_lay.setSpacing(6)

        preview_head = QHBoxLayout()
        preview_label = QLabel("PREVIEW")
        preview_label.setObjectName("previewLabel")
        preview_hint = QLabel("Atualiza conforme você liga ou desliga os módulos")
        preview_hint.setObjectName("muted")
        preview_head.addWidget(preview_label)
        preview_head.addStretch()
        preview_head.addWidget(preview_hint)
        preview_lay.addLayout(preview_head)

        self.preview = OverlayPreview()
        preview_lay.addWidget(self.preview)
        main.addWidget(preview_card)

        # ========================================================
        # 01 QUICK PRESETS
        # ========================================================
        presets = SectionCard(
            1,
            "Presets rápidos",
            "Aplique uma base e continue personalizando sem alterar posição ou volante escolhido"
        )
        preset_row = QHBoxLayout()
        preset_row.setSpacing(14)
        self.preset_buttons = {}
        self.preset_previews = {}
        preset_defs = (
            ("complete", "COMPLETO", "Todos os módulos", {"show_history":True,"show_bars":True,"show_wheel":True,"show_info":True,"show_fuel":True,"show_active_aero":True}),
            ("compact", "COMPACTO", "Sem volante, combustível e DRS", {"show_history":True,"show_bars":True,"show_wheel":False,"show_info":True,"show_fuel":False,"show_active_aero":False}),
            ("minimal", "MINIMALISTA", "Barras + informações", {"show_history":False,"show_bars":True,"show_wheel":False,"show_info":True,"show_fuel":False,"show_active_aero":False}),
        )
        for key, title, description, module_settings in preset_defs:
            card = QFrame(); card.setObjectName("presetCard")
            cl = QVBoxLayout(card); cl.setContentsMargins(12,12,12,12); cl.setSpacing(10); card.setMinimumHeight(184)
            mini = OverlayPreview(mini=True); mini.setFixedHeight(96)
            preview_settings = dict(DEFAULTS); preview_settings.update(module_settings)
            mini.setSettings(preview_settings)
            self.preset_previews[key] = mini
            btn = QPushButton(f"{title}\n{description}")
            btn.setObjectName("presetButton")
            btn.setMinimumHeight(64)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self._apply_preset(k))
            self.preset_buttons[key] = btn
            cl.addWidget(mini); cl.addWidget(btn)
            preset_row.addWidget(card, 1)
        presets.layout.addLayout(preset_row)
        self.preset_status = QLabel("Configuração personalizada")
        self.preset_status.setObjectName("muted")
        presets.layout.addWidget(self.preset_status)
        main.addWidget(presets)

        # ========================================================
        # 02 APPEARANCE
        # ========================================================
        appearance = SectionCard(
            2,
            "Aparência",
            "Tamanho da overlay, transparência e janela de dados"
        )

        grid = QGridLayout()
        grid.setHorizontalSpacing(22)
        grid.setVerticalSpacing(14)

        self.scale_row = SliderRow(
            "Escala", .50, 1.60, 1.0,
            lambda v: f"{v:.2f}x"
        )
        self.opacity_row = SliderRow(
            "Opacidade", .25, 1.0, 1.0,
            lambda v: f"{round(v * 100)}%"
        )
        self.width_row = SliderRow(
            "Largura", .65, 1.60, 1.0,
            lambda v: f"{v:.2f}x"
        )
        self.height_row = SliderRow(
            "Altura", .65, 1.60, 1.0,
            lambda v: f"{v:.2f}x"
        )

        grid.addWidget(self.scale_row, 0, 0)
        grid.addWidget(self.opacity_row, 0, 1)
        grid.addWidget(self.width_row, 1, 0)
        grid.addWidget(self.height_row, 1, 1)

        appearance.layout.addLayout(grid)

        self.history_row = SliderRow(
            "Duração do histórico",
            1.5, 8.0, 3.2,
            lambda v: f"{v:.1f}s"
        )
        appearance.layout.addWidget(self.history_row)

        self.history_style_row = SegmentedOptionRow(
            "Estilo do histórico",
            "Escolha entre o visual clássico atual e a versão Signature inspirada no visual do seu site.",
            [("classic", "CLÁSSICO"), ("site", "SIGNATURE")],
            self.settings.get("history_style", "classic")
        )
        appearance.layout.addWidget(self.history_style_row)

        main.addWidget(appearance)

        # ========================================================
        # 03 DISPLAY & BEHAVIOR
        # ========================================================
        elements = SectionCard(
            3,
            "Exibição & Comportamento",
            "Escolha o que aparece — o layout se compacta automaticamente"
        )

        self.element_rows = {}

        specs = [
            (
                "show_info",
                "Informações",
                "Marcha, velocidade e MODE"
            ),
            (
                "show_history",
                "Histórico T / B",
                "Traçado de acelerador e freio"
            ),
            (
                "show_bars",
                "Barras T / B / ERS",
                "Pedais e energia em tempo real"
            ),
            (
                "show_wheel",
                "Volante",
                "Volante sincronizado com o steering"
            ),
            (
                "show_fuel",
                "Combustível",
                "Percentual e coluna de combustível"
            ),
            (
                "show_active_aero",
                "Active Aero / DRS",
                "Indicador superior de disponibilidade"
            ),
        ]

        for key, title, description in specs:
            row = ToggleRow(
                title,
                description,
                True
            )
            row.changed.connect(
                lambda value, k=key: self._set(k, value)
            )
            self.element_rows[key] = row
            elements.layout.addWidget(row)

        main.addWidget(elements)

        # ========================================================
        # 04 ARC MODE CONTROL — rendering is implemented by overlay module
        # ========================================================
        arc = SectionCard(
            4,
            "Modo Arco",
            "Curva a overlay para acompanhar visualmente o halo do carro"
        )
        self.arc_row = ToggleRow(
            "Ativar Modo Arco",
            "Desligado por padrão. Quando desativado, a overlay reta permanece inalterada.",
            False
        )
        self.arc_row.changed.connect(lambda v: self._set("arc_mode", v))
        arc.layout.addWidget(self.arc_row)
        self.arc_preview = ArcControlPreview()
        arc.layout.addWidget(self.arc_preview)
        self.arc_intensity_row = SliderRow(
            "Intensidade da curvatura", 0.0, 1.0, 0.50,
            lambda v: f"{round(v * 100)}%"
        )
        self.arc_intensity_row.changed.connect(lambda v: self._set("arc_intensity", v))
        arc.layout.addWidget(self.arc_intensity_row)
        arc_presets = QHBoxLayout(); arc_presets.setSpacing(8)
        for text, value in (("SUAVE", .25), ("MÉDIO", .55), ("FORTE", 1.00)):
            b = QPushButton(text); b.setObjectName("ghostButton"); b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda checked=False, x=value: self._set_arc_intensity(x))
            arc_presets.addWidget(b)
        restore_arc = QPushButton("RESTAURAR"); restore_arc.setObjectName("ghostButton"); restore_arc.setCursor(Qt.PointingHandCursor)
        restore_arc.clicked.connect(lambda: self._restore_arc())
        arc_presets.addWidget(restore_arc); arc_presets.addStretch()
        arc.layout.addLayout(arc_presets)
        arc_note = QLabel("O Modo Arco curva a overlay real para acompanhar melhor o formato do halo. Use Suave, Médio ou Forte e ajuste a intensidade até encaixar no seu cockpit.")
        arc_note.setObjectName("muted"); arc_note.setWordWrap(True); arc.layout.addWidget(arc_note)
        main.addWidget(arc)

        # ========================================================
        # 05 WINDOW
        # ========================================================
        behavior = SectionCard(
            5,
            "Janela",
            "Posição e interação da overlay"
        )

        self.always_row = ToggleRow(
            "Sempre no topo",
            "Mantém a overlay sobre o jogo",
            True
        )
        self.lock_row = ToggleRow(
            "Bloquear posição",
            "Impede movimentos acidentais",
            False
        )
        self.auto_row = ToggleRow(
            "Ativar ao detectar F1",
            "Mostra a overlay automaticamente quando o jogo conectar",
            False
        )

        self.always_row.changed.connect(
            lambda v: self._set("always_on_top", v)
        )
        self.lock_row.changed.connect(
            lambda v: self._set("lock_position", v)
        )
        self.auto_row.changed.connect(
            lambda v: self._set("auto_activate_on_connect", v)
        )

        behavior.layout.addWidget(self.always_row)
        behavior.layout.addWidget(self.lock_row)
        behavior.layout.addWidget(self.auto_row)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)

        self.move_btn = QPushButton("MOVER OVERLAY")
        self.move_btn.setObjectName("secondaryButton")
        self.move_btn.setCursor(Qt.PointingHandCursor)
        self.move_btn.clicked.connect(self._move_overlay)

        center_btn = QPushButton("CENTRALIZAR")
        center_btn.setObjectName("ghostButton")
        center_btn.setCursor(Qt.PointingHandCursor)
        center_btn.clicked.connect(self._center_overlay)

        self.test_btn = QPushButton("TESTAR OVERLAY")
        self.test_btn.setObjectName("secondaryButton")
        self.test_btn.setCursor(Qt.PointingHandCursor)
        self.test_btn.clicked.connect(self._test_overlay)

        reset_btn = QPushButton("RESTAURAR TUDO AO PADRÃO")
        reset_btn.setObjectName("ghostButton")
        reset_btn.setCursor(Qt.PointingHandCursor)
        reset_btn.clicked.connect(self._reset_defaults)

        buttons.addWidget(self.move_btn)
        buttons.addWidget(center_btn)
        buttons.addWidget(self.test_btn)
        buttons.addWidget(reset_btn)
        buttons.addStretch()

        share_buttons = QHBoxLayout()
        share_buttons.setSpacing(8)

        export_btn = QPushButton("EXPORTAR CONFIG.")
        export_btn.setObjectName("ghostButton")
        export_btn.setCursor(Qt.PointingHandCursor)
        export_btn.clicked.connect(self._export_settings)

        import_btn = QPushButton("IMPORTAR CONFIG.")
        import_btn.setObjectName("ghostButton")
        import_btn.setCursor(Qt.PointingHandCursor)
        import_btn.clicked.connect(self._import_settings)

        share_buttons.addWidget(export_btn)
        share_buttons.addWidget(import_btn)
        share_buttons.addStretch()

        behavior.layout.addLayout(buttons)
        behavior.layout.addLayout(share_buttons)

        self.behavior_card = behavior
        main.addWidget(behavior)

        main.addStretch()

        scroll.setWidget(content)
        self.pages = QStackedWidget()
        self.pages.setObjectName("pages")
        self.pages.addWidget(scroll)
        self.pages.addWidget(self._build_guide_page())
        self.pages.addWidget(self._build_wheels_page())
        self.pages.addWidget(self._build_updates_page())
        self.pages.addWidget(self._build_about_page())
        self.pages.addWidget(self._build_settings_page())
        body_layout.addWidget(self.pages, 1)

        # Connections
        self.scale_row.changed.connect(
            lambda v: self._set("scale", v)
        )
        self.width_row.changed.connect(
            lambda v: self._set("width_factor", v)
        )
        self.height_row.changed.connect(
            lambda v: self._set("height_factor", v)
        )
        self.opacity_row.changed.connect(
            lambda v: self._set("opacity", v)
        )
        self.history_row.changed.connect(
            self._history_changed
        )
        self.history_style_row.changed.connect(
            lambda value: self._set("history_style", value)
        )

    def _build_guide_page(self):
        page = QScrollArea()
        page.setWidgetResizable(True)
        page.setFrameShape(QFrame.NoFrame)
        page.setObjectName("scroll")

        content = QWidget()
        content.setObjectName("mainContent")

        lay = QVBoxLayout(content)
        lay.setContentsMargins(44, 30, 44, 36)
        lay.setSpacing(14)

        eyebrow = QLabel("AJUDA")
        eyebrow.setObjectName("eyebrow")
        title = QLabel("Guia de Configuração")
        title.setObjectName("pageTitle")
        subtitle = QLabel(
            "Configure o F1 26 uma vez e depois basta abrir o Zoltraak Control."
        )
        subtitle.setObjectName("pageSubtitle")

        lay.addWidget(eyebrow)
        lay.addWidget(title)
        lay.addWidget(subtitle)
        lay.addSpacing(8)

        step1 = GuideStep(
            1,
            "Ative a telemetria no F1 26",
            [
                "Abra o F1 26 e vá até as configurações de Telemetria.",
                "Ative Telemetria por UDP e deixe o modo de transmissão por UDP em SIM."
            ]
        )

        step2 = GuideStep(
            2,
            "Use estes valores",
            [
                "IP: 127.0.0.1",
                "Porta UDP: 20777",
                "Taxa de envio: 60 Hz",
                "Formato UDP: 2026",
                "Telemetria pública: SIM"
            ]
        )

        step3 = GuideStep(
            3,
            "Abra o Zoltraak Control",
            [
                "Com o jogo aberto, inicie o Zoltraak Control.",
                "Quando a telemetria estiver chegando, o status na sidebar muda de WAITING FOR F1 para F1 26 CONNECTED."
            ]
        )

        step4 = GuideStep(
            4,
            "Ative a overlay",
            [
                "Clique em ATIVAR.",
                "Entre em uma sessão e confirme que pedais, volante, marcha, velocidade, combustível e Active Aero respondem em tempo real."
            ]
        )

        step5 = GuideStep(
            5,
            "Se não conectar",
            [
                "Confirme novamente IP 127.0.0.1, porta 20777 e formato 2026.",
                "Evite deixar outro aplicativo usando a mesma porta UDP ao mesmo tempo.",
                "Se necessário, feche e abra novamente o Zoltraak Control depois de corrigir as opções no jogo."
            ]
        )

        for step in (step1, step2, step3, step4, step5):
            lay.addWidget(step)

        note = QLabel(
            "Dica: depois da primeira configuração, normalmente você não precisa mexer mais nas opções de telemetria do F1 26."
        )
        note.setObjectName("guideNote")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addStretch()

        page.setWidget(content)
        return page

    def _refresh_release_data(self):
        if hasattr(self, "updates_check_label"):
            self.updates_check_label.setText("Estado · verificando agora…")
        if hasattr(self, "downloads_updated_label"):
            self.downloads_updated_label.setText("Última consulta · atualizando...")
            self.downloads_updated_label.setProperty("status", "neutral")
            self.downloads_updated_label.style().unpolish(self.downloads_updated_label)
            self.downloads_updated_label.style().polish(self.downloads_updated_label)
        self._refresh_download_count()
        self._refresh_latest_release_info()

    def _refresh_latest_release_info(self):
        if not hasattr(self, "latest_release_label"):
            return

        if not GITHUB_OWNER.strip() or not GITHUB_REPO.strip():
            self._set_latest_release_info(None)
            return

        threading.Thread(
            target=self._fetch_latest_release_worker,
            daemon=True
        ).start()

    def _fetch_latest_release_worker(self):
        try:
            req = urllib.request.Request(
                DOWNLOAD_LATEST_API,
                headers={
                    "Accept": "application/vnd.github+json",
                    "User-Agent": "Zoltraak-Control"
                }
            )
            with urllib.request.urlopen(req, timeout=12) as response:
                payload = json.loads(response.read().decode("utf-8"))

            info = {
                "tag": payload.get("tag_name") or payload.get("name") or "",
                "name": payload.get("name") or payload.get("tag_name") or "",
                "url": payload.get("html_url") or DOWNLOAD_RELEASES_URL,
            }
            self.latest_release_ready.emit(info)
        except Exception:
            self.latest_release_ready.emit(None)

    def _refresh_download_count(self):
        if not hasattr(self, "downloads_label"):
            return

        if not GITHUB_OWNER.strip() or not GITHUB_REPO.strip():
            self.downloads_label.setText("Downloads · —")
            self.downloads_label.setToolTip(
                "Repositório de downloads ainda não configurado."
            )
            return

        # Keep network I/O away from the Qt UI thread.
        threading.Thread(
            target=self._fetch_download_count_worker,
            daemon=True
        ).start()

    def _fetch_download_count_worker(self):
        req = urllib.request.Request(
            DOWNLOAD_RELEASES_API,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": f"Zoltraak-Control/{APP_VERSION}",
                "Cache-Control": "no-cache",
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=12) as response:
                releases = json.loads(response.read().decode("utf-8"))

            if not isinstance(releases, list):
                raise ValueError("Resposta inesperada da API de Releases")

            total = 0
            matched_assets = 0

            for release in releases:
                for asset in release.get("assets", []):
                    name = str(asset.get("name", ""))
                    if is_download_asset(name):
                        matched_assets += 1
                        total += int(asset.get("download_count", 0) or 0)

            self.download_count_ready.emit({
                "total": total,
                "assets": matched_assets,
                "updated_at": time.time(),
            })

        except Exception as exc:
            self.download_count_ready.emit({
                "error": str(exc),
                "updated_at": time.time(),
            })

    def _set_download_count(self, value):
        if not hasattr(self, "downloads_label"):
            return

        if not isinstance(value, dict) or value.get("error"):
            self.downloads_label.setText("Downloads · indisponível")
            self.downloads_label.setToolTip(
                "Não foi possível consultar os downloads neste momento."
            )
            if hasattr(self, "downloads_updated_label"):
                self.downloads_updated_label.setText("Última consulta · falhou")
                self.downloads_updated_label.setProperty("status", "warning")
                self.downloads_updated_label.style().unpolish(self.downloads_updated_label)
                self.downloads_updated_label.style().polish(self.downloads_updated_label)
            return

        total = int(value.get("total", 0) or 0)
        matched_assets = int(value.get("assets", 0) or 0)
        formatted = f"{total:,}".replace(",", ".")

        self.downloads_label.setText(f"Downloads · {formatted}")
        self.downloads_label.setToolTip(
            f"Total informado pelo GitHub para {matched_assets} instalador(es) publicado(s)."
        )

        if hasattr(self, "downloads_updated_label"):
            stamp = value.get("updated_at") or time.time()
            clock = time.strftime("%H:%M:%S", time.localtime(stamp))
            self.downloads_updated_label.setText(f"Última consulta · {clock}")
            self.downloads_updated_label.setProperty("status", "ok")
            self.downloads_updated_label.style().unpolish(self.downloads_updated_label)
            self.downloads_updated_label.style().polish(self.downloads_updated_label)

    def _set_latest_release_info(self, info):
        if not hasattr(self, "latest_release_label"):
            return

        if not info:
            self.latest_release_label.setText("Última versão · indisponível")
            self.update_status_label.setText("Estado da atualização · não foi possível verificar")
            self.update_status_label.setProperty("status", "warning")
            self.open_downloads_btn.setText("Abrir downloads")
            self.latest_release_url = DOWNLOAD_RELEASES_URL
        else:
            tag = info.get("tag") or ""
            pretty_tag = format_tag(tag)
            normalized_tag = pretty_tag.lower()
            self.latest_release_url = info.get("url") or DOWNLOAD_RELEASES_URL
            self.latest_release_label.setText(f"Última versão · {pretty_tag}")
            if normalized_tag in LEGACY_RELEASE_TAGS:
                self.update_status_label.setText(f"Versão oficial instalada · v{APP_VERSION}")
                self.update_status_label.setProperty("status", "ok")
                self.open_downloads_btn.setText("Abrir downloads")
            elif version_key(tag) > version_key(APP_VERSION):
                self.update_status_label.setText(f"Atualização disponível · {pretty_tag}")
                self.update_status_label.setProperty("status", "update")
                self.open_downloads_btn.setText("Baixar atualização")
            else:
                self.update_status_label.setText(f"Você está na versão atual · v{APP_VERSION}")
                self.update_status_label.setProperty("status", "ok")
                self.open_downloads_btn.setText("Abrir downloads")

        if hasattr(self, "updates_check_label"):
            try:
                self.updates_check_label.setText(self.update_status_label.text().replace("Estado da atualização", "Estado"))
            except Exception:
                pass

        for widget in (self.latest_release_label, self.update_status_label):
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    def _open_downloads_page(self):
        try:
            webbrowser.open(self.latest_release_url or DOWNLOAD_RELEASES_URL)
        except Exception:
            pass

    def _build_wheels_page(self):
        page = QScrollArea(); page.setWidgetResizable(True); page.setFrameShape(QFrame.NoFrame); page.setObjectName("scroll")
        content = QWidget(); content.setObjectName("mainContent")
        lay = QVBoxLayout(content); lay.setContentsMargins(44, 30, 44, 36); lay.setSpacing(14)

        eyebrow=QLabel("HARDWARE"); eyebrow.setObjectName("eyebrow")
        title=QLabel("Volante & Perfis"); title.setObjectName("pageTitle")
        subtitle=QLabel("Aqui você escolhe apenas qual volante aparece desenhado na overlay. Isso não muda Force Feedback, calibração ou configurações do jogo.")
        subtitle.setObjectName("pageSubtitle"); subtitle.setWordWrap(True)
        lay.addWidget(eyebrow); lay.addWidget(title); lay.addWidget(subtitle); lay.addSpacing(8)

        status=SectionCard(1,"Seu volante","O Control lê localmente o nome informado pelo Windows")
        self.wheel_status_label=QLabel("Status · aguardando detecção"); self.wheel_status_label.setObjectName("aboutInfoLabel")
        self.wheel_device_label=QLabel("Volante conectado · —"); self.wheel_device_label.setObjectName("aboutInfoLabel")
        self.wheel_profile_label=QLabel("Perfil visual · Volante padrão Zoltraak"); self.wheel_profile_label.setObjectName("aboutInfoLabel")
        self.wheel_remote_label=QLabel("Perfil online · aguardando verificação"); self.wheel_remote_label.setObjectName("guideNote"); self.wheel_remote_label.setWordWrap(True)
        for w in (self.wheel_status_label,self.wheel_device_label,self.wheel_profile_label,self.wheel_remote_label): status.layout.addWidget(w)
        buttons=QHBoxLayout(); buttons.setSpacing(8)
        detect=QPushButton("DETECTAR NOVAMENTE"); detect.setObjectName("secondaryButton"); detect.clicked.connect(self._manual_wheel_detection)
        check=QPushButton("VERIFICAR PERFIL ONLINE"); check.setObjectName("secondaryButton"); check.clicked.connect(lambda: self._check_remote_profile(silent=False))
        default=QPushButton("USAR VOLANTE PADRÃO"); default.setObjectName("ghostButton"); default.clicked.connect(self._restore_default_wheel)
        self.wheel_conclude_btn=QPushButton("CONCLUIR"); self.wheel_conclude_btn.setObjectName("aboutActionButton"); self.wheel_conclude_btn.clicked.connect(lambda: self._show_page("overlay")); self.wheel_conclude_btn.hide()
        buttons.addWidget(detect); buttons.addWidget(check); buttons.addWidget(default); buttons.addWidget(self.wheel_conclude_btn); buttons.addStretch(); status.layout.addLayout(buttons)
        lay.addWidget(status)

        flow=SectionCard(2,"Como funciona","Três situações possíveis")
        txt=QLabel(
            "DETECTADO + PERFIL INSTALADO · usa o perfil imediatamente.\n\n"
            "DETECTADO + PERFIL DISPONÍVEL ONLINE · o Control baixa somente o perfil visual e ativa, sem atualizar o programa inteiro.\n\n"
            "DETECTADO + SEM PERFIL · o hardware foi reconhecido normalmente, mas ainda não existe um desenho específico aprovado. A telemetria continua normal com o Volante Padrão Zoltraak e você pode solicitar um perfil."
        ); txt.setObjectName("guideBody"); txt.setWordWrap(True); flow.layout.addWidget(txt); lay.addWidget(flow)

        request=SectionCard(3,"Seu volante ainda não tem perfil?","Envie uma solicitação sem GitHub e sem login")
        note=QLabel("Informe somente marca, modelo e, se quiser, uma foto. A solicitação é enviada diretamente para o responsável pelo projeto. O prazo estimado para análise e preparação é de 3 dias a 1 semana.")
        note.setObjectName("guideBody"); note.setWordWrap(True); request.layout.addWidget(note)
        req=QPushButton("SOLICITAR PERFIL"); req.setObjectName("aboutActionButton"); req.clicked.connect(self._open_wheel_compatibility); request.layout.addWidget(req,0,Qt.AlignLeft)
        privacy=QLabel("Privacidade · a detecção normal é local. Nenhum número de série é coletado. A internet só é usada para verificar perfis online ou quando você envia uma solicitação.")
        privacy.setObjectName("guideNote"); privacy.setWordWrap(True); request.layout.addWidget(privacy); lay.addWidget(request)

        lay.addStretch(); page.setWidget(content); return page

    def _refresh_wheel_page(self, names=None):
        if not hasattr(self,"wheel_status_label"): return
        names=list(names or [])
        detected=names[0] if names else str(self.app_state.get("detected_wheel_name","") or self.settings.get("wheel_device_name",""))
        profile_name=str(self.settings.get("wheel_profile_name","Volante padrão Zoltraak"))
        profile_path=str(self.settings.get("wheel_profile_path","") or "")
        if not detected:
            if hasattr(self,"wheel_conclude_btn"): self.wheel_conclude_btn.hide()
            self.wheel_status_label.setText("Status · nenhum volante identificado"); self.wheel_status_label.setProperty("status","warning")
            self.wheel_device_label.setText("Volante conectado · —")
            self.wheel_profile_label.setText(f"Perfil visual · {profile_name}")
        else:
            if hasattr(self,"wheel_conclude_btn"): self.wheel_conclude_btn.show()
            match=match_catalog(detected)
            self.wheel_status_label.setText("✓ VOLANTE DETECTADO COM SUCESSO"); self.wheel_status_label.setProperty("status","ok")
            self.wheel_device_label.setText(f"Volante conectado · {match['display'] if match else detected}")
            if profile_path and Path(profile_path).exists() and self.settings.get("wheel_profile") != "default":
                self.wheel_profile_label.setText(f"Perfil visual · {profile_name} · instalado")
            else:
                self.wheel_profile_label.setText("Perfil visual em uso · Volante padrão Zoltraak")
        for w in (self.wheel_status_label,self.wheel_device_label,self.wheel_profile_label):
            w.style().unpolish(w); w.style().polish(w)

    def _manual_wheel_detection(self):
        dialog=WheelDetectionDialog(None,self); dialog.choiceMade.connect(self._wheel_assistant_choice); self._exec_dimmed(dialog)
        detected=dialog.detected_names[0] if dialog.detected_names else ""
        if detected:
            self.app_state["detected_wheel_name"]=detected; self.settings["wheel_device_name"]=detected; self._schedule_save(); save_app_state(self.app_state)
        self._refresh_wheel_page([detected] if detected else [])
        if detected: self._check_remote_profile(silent=True)

    def _open_wheel_compatibility(self):
        detected=str(self.app_state.get("detected_wheel_name","") or self.settings.get("wheel_device_name",""))
        dialog=WheelCompatibilityDialog(APP_VERSION,detected,self)
        self._exec_dimmed(dialog)

    def _restore_default_wheel(self):
        self.settings["wheel_profile"]="default"; self.settings["wheel_profile_name"]="Volante padrão Zoltraak"; self.settings["wheel_profile_path"]=""
        self.settings["wheel_profile_width"]=96.0; self.settings["wheel_profile_offset_x"]=0.0; self.settings["wheel_profile_offset_y"]=0.0; self.settings["wheel_profile_steering_degrees"]=360.0
        self._schedule_save(); self.overlay.apply_settings(self.settings); self._refresh_wheel_page()
        if hasattr(self,"preview"): self.preview.setSettings(self.settings)
        self._show_status_toast("VOLANTE PADRÃO ATIVADO","A overlay voltou a usar o perfil visual padrão Zoltraak.","#6aa8ff")

    def _check_remote_profile(self, silent=False):
        detected=str(self.app_state.get("detected_wheel_name","") or self.settings.get("wheel_device_name",""))
        if not detected:
            if not silent: QMessageBox.information(self,"Perfil online","Detecte um volante antes de verificar perfis online.")
            return
        if hasattr(self,"wheel_remote_label"): self.wheel_remote_label.setText("Perfil online · verificando catálogo…")
        def worker():
            catalog=fetch_remote_profile_catalog(); profile=match_remote_profile(detected,catalog)
            self.remote_profile_ready.emit({"profile":profile,"device":detected,"silent":bool(silent)})
        threading.Thread(target=worker,daemon=True).start()

    def _apply_remote_profile_result(self,payload):
        payload=payload if isinstance(payload,dict) else {}; profile=payload.get("profile"); silent=bool(payload.get("silent"))
        if not profile:
            if hasattr(self,"wheel_remote_label"): self.wheel_remote_label.setText("Perfil específico · ainda não disponível · usando o Volante padrão Zoltraak")
            if not silent: self._show_status_toast("PERFIL AINDA NÃO DISPONÍVEL","Você pode solicitar um perfil. Enquanto isso, o volante padrão continua funcionando normalmente.","#ffb454")
            return
        name=str(profile.get("name") or profile.get("model") or "Perfil remoto")
        if hasattr(self,"wheel_remote_label"): self.wheel_remote_label.setText(f"Perfil online disponível · {name}")
        answer=QMessageBox.question(self,"Novo perfil disponível",f"Encontramos um perfil visual aprovado para este volante:\n\n{name}\n\nBaixar e ativar agora?",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)
        if answer!=QMessageBox.Yes: return
        try:
            meta=install_remote_profile(profile)
            self.settings["wheel_profile"]=str(profile.get("key") or "remote")
            self.settings["wheel_profile_name"]=name
            self.settings["wheel_profile_path"]=str(meta.get("installed_image", ""))
            self.settings["wheel_profile_width"]=float(profile.get("target_width", 96.0))
            self.settings["wheel_profile_offset_x"]=float(profile.get("offset_x", 0.0))
            self.settings["wheel_profile_offset_y"]=float(profile.get("offset_y", 0.0))
            self.settings["wheel_profile_steering_degrees"]=float(profile.get("steering_total_degrees", 360.0))
            self._schedule_save(); self.overlay.apply_settings(self.settings); self._refresh_wheel_page()
            if hasattr(self,"preview"): self.preview.setSettings(self.settings)
            self._show_status_toast("PERFIL INSTALADO",f"{name} foi baixado e ativado sem atualizar o Zoltraak Control.","#38d98a")
        except Exception as exc:
            QMessageBox.warning(self,"Não foi possível instalar",f"O perfil foi encontrado, mas não pôde ser instalado.\n\n{exc}")

    def _build_updates_page(self):
        page = QScrollArea(); page.setWidgetResizable(True); page.setFrameShape(QFrame.NoFrame); page.setObjectName("scroll")
        content = QWidget(); content.setObjectName("mainContent")
        lay = QVBoxLayout(content); lay.setContentsMargins(44,30,44,36); lay.setSpacing(14)
        e=QLabel("VERSÃO"); e.setObjectName("eyebrow")
        t=QLabel("Atualizações"); t.setObjectName("pageTitle")
        sub=QLabel("Verifique manualmente, consulte as novidades e abra a página oficial de downloads."); sub.setObjectName("pageSubtitle")
        lay.addWidget(e); lay.addWidget(t); lay.addWidget(sub); lay.addSpacing(8)

        current=SectionCard(1, "Versão instalada", "A verificação automática pode falhar; a consulta manual fica sempre disponível")
        self.updates_version_label=QLabel(f"Versão atual · v{APP_VERSION}"); self.updates_version_label.setObjectName("aboutInfoLabel")
        self.updates_check_label=QLabel("Estado · aguardando verificação"); self.updates_check_label.setObjectName("aboutInfoLabel")
        current.layout.addWidget(self.updates_version_label); current.layout.addWidget(self.updates_check_label)
        row=QHBoxLayout(); row.setSpacing(8)
        b=QPushButton("VERIFICAR ATUALIZAÇÕES"); b.setObjectName("aboutActionButton"); b.clicked.connect(self._refresh_release_data)
        notes=QPushButton("NOVIDADES DESTA VERSÃO"); notes.setObjectName("aboutSecondaryButton"); notes.clicked.connect(self._open_release_notes)
        downloads=QPushButton("ABRIR DOWNLOADS"); downloads.setObjectName("aboutSecondaryButton"); downloads.clicked.connect(self._open_downloads_page)
        row.addWidget(b); row.addWidget(notes); row.addWidget(downloads); row.addStretch(); current.layout.addLayout(row); lay.addWidget(current)

        changes=SectionCard(2, f"Novidades · v{APP_VERSION}", f"Atualizado em {RELEASE_DATE}")
        for note in RELEASE_NOTES:
            card=QFrame(); card.setObjectName("updateInlineCard")
            cl=QVBoxLayout(card); cl.setContentsMargins(12,10,12,10); cl.setSpacing(3)
            badge=QLabel(note["badge"]); badge.setStyleSheet(f"color:{note['accent']};font-size:10px;font-weight:800;")
            title=QLabel(note["title"]); title.setObjectName("guideTitle")
            body=QLabel(note["body"]); body.setObjectName("guideBody"); body.setWordWrap(True)
            cl.addWidget(badge); cl.addWidget(title); cl.addWidget(body); changes.layout.addWidget(card)
        lay.addWidget(changes); lay.addStretch(); page.setWidget(content); return page

    def _build_settings_page(self):
        page = QScrollArea(); page.setWidgetResizable(True); page.setFrameShape(QFrame.NoFrame); page.setObjectName("scroll")
        content=QWidget(); content.setObjectName("mainContent")
        lay=QVBoxLayout(content); lay.setContentsMargins(44,30,44,36); lay.setSpacing(14)
        e=QLabel("PREFERÊNCIAS"); e.setObjectName("eyebrow")
        t=QLabel("Configurações"); t.setObjectName("pageTitle")
        sub=QLabel("Animações e ferramentas para repetir a introdução ou refazer a detecção."); sub.setObjectName("pageSubtitle")
        lay.addWidget(e); lay.addWidget(t); lay.addWidget(sub); lay.addSpacing(8)

        ui=SectionCard(1,"Interface","Ajustes visuais locais")
        self.reduce_anim_row=ToggleRow("Reduzir animações","Diminui fades e movimentos decorativos",False)
        self.reduce_anim_row.changed.connect(lambda v:self._set("reduce_animations",v))
        self.decorative_row=ToggleRow("Efeitos decorativos","Mantém brilhos e detalhes visuais discretos",True)
        self.decorative_row.changed.connect(lambda v:self._set("decorative_effects",v))
        ui.layout.addWidget(self.reduce_anim_row); ui.layout.addWidget(self.decorative_row); lay.addWidget(ui)

        tools=SectionCard(2,"Ferramentas","Ações que permanecem disponíveis depois da primeira abertura")
        row=QHBoxLayout(); row.setSpacing(8)
        intro=QPushButton("REFAZER INTRODUÇÃO"); intro.setObjectName("secondaryButton"); intro.clicked.connect(self._replay_onboarding)
        detect=QPushButton("DETECTAR VOLANTE"); detect.setObjectName("secondaryButton"); detect.clicked.connect(lambda:self._start_wheel_detection(False))
        updates=QPushButton("VERIFICAR ATUALIZAÇÕES"); updates.setObjectName("secondaryButton"); updates.clicked.connect(self._refresh_release_data)
        row.addWidget(intro); row.addWidget(detect); row.addWidget(updates); row.addStretch(); tools.layout.addLayout(row)
        lay.addWidget(tools); lay.addStretch(); page.setWidget(content); return page

    def _replay_onboarding(self):
        dialog=OnboardingDialog(APP_VERSION, verify_updates_callback=self._refresh_release_data, resource_resolver=resource_path, parent=self)
        self._exec_dimmed(dialog)

    def _build_about_page(self):
        page = QScrollArea()
        page.setWidgetResizable(True)
        page.setFrameShape(QFrame.NoFrame)
        page.setObjectName("scroll")

        content = QWidget()
        content.setObjectName("mainContent")

        lay = QVBoxLayout(content)
        lay.setContentsMargins(44, 30, 44, 36)
        lay.setSpacing(14)

        eyebrow = QLabel("ZOLTRAAK")
        eyebrow.setObjectName("eyebrow")
        title = QLabel("Sobre")
        title.setObjectName("pageTitle")
        subtitle = QLabel("Informações do Zoltraak Control e histórico desta versão.")
        subtitle.setObjectName("pageSubtitle")

        lay.addWidget(eyebrow)
        lay.addWidget(title)
        lay.addWidget(subtitle)
        lay.addSpacing(10)

        card = QFrame()
        card.setObjectName("aboutCard")
        card_lay = QVBoxLayout(card)
        card_lay.setContentsMargins(20, 18, 20, 18)
        card_lay.setSpacing(8)

        about_logo = QLabel()
        about_logo.setObjectName("aboutLogo")
        about_logo.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        about_logo.setMinimumHeight(70)

        logo_file = resource_path("assets/zoltraak_logo_horizontal.png")
        if logo_file.exists():
            pix = QPixmap(str(logo_file))
            if not pix.isNull():
                pix = pix.scaled(
                    330, 78,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
                about_logo.setPixmap(pix)

        if about_logo.pixmap() is None or about_logo.pixmap().isNull():
            about_logo.setText("Zoltraak Control")

        product = QLabel("Telemetry Control · Projeto Pessoal")
        product.setObjectName("aboutProduct")
        version = QLabel(f"Versão {APP_VERSION}")
        version.setObjectName("aboutVersion")
        credit = QLabel("Made by PedroZoltraak")
        credit.setObjectName("aboutCredit")

        self.downloads_label = QLabel("Downloads · sincronizando...")
        self.downloads_label.setObjectName("downloadsLabel")
        self.downloads_updated_label = QLabel("Última consulta · aguardando...")
        self.downloads_updated_label.setObjectName("aboutInfoLabel")
        self.downloads_updated_label.setProperty("status", "neutral")
        self.latest_release_label = QLabel("Última versão · verificando...")
        self.latest_release_label.setObjectName("aboutInfoLabel")
        self.update_status_label = QLabel(f"Estado da atualização · verificando...")
        self.update_status_label.setObjectName("aboutInfoLabel")
        self.update_status_label.setProperty("status", "neutral")

        actions_row = QHBoxLayout()
        actions_row.setSpacing(10)

        self.refresh_release_btn = QPushButton("Verificar agora")
        self.refresh_release_btn.setObjectName("aboutSecondaryButton")
        self.refresh_release_btn.clicked.connect(self._refresh_release_data)

        self.open_downloads_btn = QPushButton("Abrir downloads")
        self.open_downloads_btn.setObjectName("aboutActionButton")
        self.open_downloads_btn.clicked.connect(self._open_downloads_page)

        actions_row.addWidget(self.refresh_release_btn)
        actions_row.addWidget(self.open_downloads_btn)
        actions_row.addStretch(1)

        card_lay.addWidget(about_logo)
        card_lay.addSpacing(4)
        card_lay.addWidget(product)
        card_lay.addWidget(version)
        card_lay.addSpacing(4)
        card_lay.addWidget(credit)
        card_lay.addSpacing(8)
        card_lay.addWidget(self.downloads_label)
        card_lay.addWidget(self.downloads_updated_label)
        card_lay.addWidget(self.latest_release_label)
        card_lay.addWidget(self.update_status_label)
        card_lay.addLayout(actions_row)
        lay.addWidget(card)

        change = SectionCard(
            1,
            f"Novidades da v{APP_VERSION}",
            f"Primeira versão oficial · {RELEASE_DATE}"
        )
        for note in RELEASE_NOTES:
            lbl = QLabel(f"• {note['badge']} · {note['title']}")
            lbl.setObjectName("guideBody")
            change.layout.addWidget(lbl)
        lay.addWidget(change)

        lay.addStretch()
        page.setWidget(content)
        return page

    def _show_page(self, page):
        index = {
            "overlay": 0,
            "guide": 1,
            "wheels": 2,
            "updates": 3,
            "about": 4,
            "settings": 5,
        }.get(page, 0)
        self.pages.setCurrentIndex(index)

        navs = {
            "overlay": self.nav_overlay,
            "guide": self.nav_guide,
            "wheels": self.nav_wheels,
            "updates": self.nav_updates,
            "about": self.nav_about,
            "settings": self.nav_settings,
        }
        for key, widget in navs.items():
            widget.setProperty("selected", page == key)
            widget.style().unpolish(widget)
            widget.style().polish(widget)


        # Short, restrained page fade. It is skipped when Reduced Animations is enabled.
        if not self.settings.get("reduce_animations", False):
            current = self.pages.currentWidget()
            effect = QGraphicsOpacityEffect(current)
            current.setGraphicsEffect(effect)
            self._page_anim = QPropertyAnimation(effect, b"opacity", self)
            self._page_anim.setDuration(190)
            self._page_anim.setStartValue(0.25)
            self._page_anim.setEndValue(1.0)
            self._page_anim.setEasingCurve(QEasingCurve.OutCubic)
            self._page_anim.finished.connect(lambda w=current: w.setGraphicsEffect(None))
            self._page_anim.start()

    def _apply_style(self):
        self.setStyleSheet("""
            * {
                font-family: "Segoe UI Variable Text", "Segoe UI";
                color: #e9e9eb;
            }

            QMainWindow {
                background: #09090a;
            }

            #windowFrame {
                background: #111112;
                border: 1px solid #29292c;
                border-radius: 4px;
            }

            #titleBar {
                background: #0a0a0b;
                border-bottom: 1px solid #252528;
            }

            #windowTitleLabel {
                color: #f0f0f1;
                font-size: 14px;
                font-weight: 650;
            }

            #windowVersionLabel {
                color: #707176;
                font-size: 11px;
                font-weight: 500;
                margin-left: 1px;
            }

            #titleButton,
            #closeButton {
                background: transparent;
                border: none;
                color: #bfc0c4;
                font-size: 16px;
                padding: 0px;
                border-radius: 0px;
            }

            #titleButton:hover {
                background: #1c1c1f;
                color: #ffffff;
            }

            #closeButton:hover {
                background: #c8323c;
                color: white;
            }

            #sidebar {
                background: #09090a;
                border-right: 1px solid #171719;
            }

            #logo {
                color: #ff424b;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 40px;
                font-weight: 900;
                font-style: italic;
            }

            #brand {
                color: #f4f4f5;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 30px;
                font-weight: 750;
            }

            #brandVersion {
                color: #68696e;
                font-size: 12px;
                font-weight: 500;
            }

            #connectionWait {
                color: #74757a;
                font-size: 12px;
                font-weight: 550;
            }

            #connectionLive {
                color: #46e985;
                font-size: 13px;
                font-weight: 650;
            }

            #sideDivider {
                background: #1c1c1f;
                border: none;
            }

            #menuLabel {
                color: #606166;
                font-size: 12px;
                font-weight: 650;
            }

            #navActive {
                text-align: left;
                padding: 0px 38px;
                background: #201012;
                border: none;
                border-left: 2px solid #ff454d;
                border-radius: 3px;
                color: #f2f2f3;
                font-size: 16px;
                font-weight: 650;
            }

            #navActive:hover {
                background: #281214;
            }

            #sideBottomButton {
                text-align: left;
                background: transparent;
                color: #9c9ca1;
                border: none;
                padding: 10px 38px;
                font-size: 14px;
                font-weight: 500;
            }

            #sideBottomButton:hover {
                color: #efeff0;
                background: #121214;
            }

            #scroll,
            #mainContent {
                background: #111112;
            }

            #eyebrow {
                color: #ff4a52;
                font-size: 12px;
                font-weight: 750;
            }

            #pageTitle {
                color: #f1f1f2;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 34px;
                font-weight: 750;
            }

            #pageSubtitle {
                color: #929399;
                font-size: 15px;
                font-weight: 400;
            }

            #statusBannerActive {
                background: #101713;
                border: 1px solid #1b432d;
                border-left: 3px solid #28df70;
                border-radius: 3px;
            }

            #statusBannerInactive {
                background: #181819;
                border: 1px solid #303034;
                border-left: 3px solid #73747a;
                border-radius: 3px;
            }

            #statusText {
                color: #31e77b;
                font-family: "Consolas";
                font-size: 12px;
                font-weight: 750;
            }

            #statusBannerInactive #statusText {
                color: #88898e;
            }

            #statusHint {
                color: #64656a;
                font-family: "Consolas";
                font-size: 12px;
                font-weight: 650;
            }

            #telemetryHealthLive {
                color: #54e98f;
                font-family: "Consolas";
                font-size: 11px;
                font-weight: 750;
            }

            #telemetryHealthWait {
                color: #6d7077;
                font-family: "Consolas";
                font-size: 11px;
                font-weight: 650;
            }

            #card {
                background: #171718;
                border: 1px solid #252528;
                border-radius: 4px;
            }

            #sectionAccent {
                background: #ff454d;
                border: none;
                border-radius: 1px;
            }

            #sectionNumber {
                color: #ff4a52;
                font-family: "Consolas";
                font-size: 12px;
                font-weight: 750;
            }

            #sectionTitle {
                color: #f0f0f2;
                font-size: 14px;
                font-weight: 750;
            }

            #sectionLine {
                background: #29292c;
                border: none;
            }

            #muted {
                color: #7b7c82;
                font-size: 13px;
                font-weight: 400;
            }

            #rowLabel {
                color: #f5f5f6;
                font-size: 15px;
                font-weight: 650;
            }

            #valueLabel {
                color: #eeeeef;
                font-size: 13px;
                font-weight: 650;
            }

            #toggleRow {
                border-bottom: 1px solid rgba(255, 255, 255, 0.035);
            }

            QSlider::groove:horizontal {
                height: 3px;
                background: #323236;
                border-radius: 1px;
            }

            QSlider::sub-page:horizontal {
                background: #ff454d;
                border-radius: 1px;
            }

            QSlider::handle:horizontal {
                background: #f5f5f6;
                width: 10px;
                margin: -4px 0px;
                border-radius: 3px;
            }

            QSlider::handle:horizontal:hover {
                background: #ffffff;
            }

            QPushButton {
                border-radius: 3px;
                padding: 7px 13px;
                font-size: 9px;
                font-weight: 650;
            }

            #secondaryButton {
                background: #211012;
                color: #ff656c;
                border: 1px solid #623036;
            }

            #secondaryButton:hover {
                background: #2a1215;
                border-color: #7a343b;
            }

            #ghostButton {
                background: transparent;
                color: #8c8d92;
                border: 1px solid #313135;
            }

            #ghostButton:hover {
                color: #dedee0;
                border-color: #49494e;
            }

            /* Overlay OFF -> ACTIVATE filled red, like Vartex */
            #activateOn {
                background: #ff454d;
                color: #ffffff;
                border: 1px solid #ff454d;
                font-size: 12px;
                font-weight: 750;
            }

            #activateOn:hover {
                background: #ff5961;
                border-color: #ff5961;
            }

            /* Overlay ON -> DEACTIVATE outlined red, like Vartex */
            #activateOff {
                background: transparent;
                color: #ff5961;
                border: 1px solid #b83a43;
                font-size: 12px;
                font-weight: 750;
            }

            #activateOff:hover {
                background: #281114;
                border-color: #df414a;
            }


            #navSecondary {
                text-align: left;
                padding: 0px 38px;
                background: transparent;
                border: none;
                border-left: 2px solid transparent;
                border-radius: 3px;
                color: #9c9ca1;
                font-size: 14px;
                font-weight: 550;
            }

            #navSecondary:hover {
                background: #121214;
                color: #eeeeef;
            }

            #navSecondary[selected="true"] {
                background: #201012;
                border-left: 2px solid #ff454d;
                color: #f2f2f3;
            }

            #navActive[selected="false"] {
                background: transparent;
                border-left: 2px solid transparent;
                color: #9c9ca1;
            }

            #navActive[selected="false"]:hover {
                background: #121214;
                color: #eeeeef;
            }

            #pages {
                background: #111112;
            }

            #previewCard {
                background: #141416;
                border: 1px solid #242428;
                border-radius: 4px;
            }

            #previewLabel {
                color: #d9d9dc;
                font-size: 12px;
                font-weight: 750;
            }

            #overlayPreview {
                background: transparent;
                border: none;
            }

            #aboutCard {
                background: #171718;
                border: 1px solid #252528;
                border-radius: 4px;
            }

            #aboutLogo {
                background: transparent;
                border: none;
                padding: 0px;
            }

            #aboutProduct {
                color: #f2f2f3;
                font-size: 24px;
                font-weight: 700;
            }

            #aboutVersion {
                color: #85868c;
                font-size: 12px;
                font-weight: 500;
            }

            #aboutCredit {
                color: #ff5a62;
                font-size: 13px;
                font-weight: 600;
            }


            #downloadsLabel {
                color: #d8d8dc;
                background: #111113;
                border: 1px solid #2b2c31;
                border-radius: 3px;
                font-size: 14px;
                font-weight: 650;
                padding: 9px 11px;
            }

            #aboutInfoLabel {
                color: #d3d4d8;
                background: #111113;
                border: 1px solid #2b2c31;
                border-radius: 3px;
                font-size: 13px;
                font-weight: 600;
                padding: 8px 11px;
            }

            #aboutInfoLabel[status="ok"] {
                color: #9af3b3;
                border-color: #235a36;
            }

            #aboutInfoLabel[status="update"] {
                color: #ffd06a;
                border-color: #6d5120;
            }

            #aboutInfoLabel[status="warning"] {
                color: #ffb0b3;
                border-color: #6e2a2d;
            }

            #aboutSecondaryButton,
            #aboutActionButton {
                min-height: 36px;
                padding: 0 16px;
                border-radius: 4px;
                font-size: 13px;
                font-weight: 700;
            }

            #aboutSecondaryButton {
                color: #ececf0;
                background: #17171a;
                border: 1px solid #31343b;
            }

            #aboutSecondaryButton:hover {
                background: #1d1e22;
                border-color: #424652;
            }

            #aboutActionButton {
                color: #ffffff;
                background: #ff4b55;
                border: 1px solid #ff4b55;
            }

            #aboutActionButton:hover {
                background: #ff5b64;
                border-color: #ff5b64;
            }

            #presetCard {
                background: #111113;
                border: 1px solid #27282d;
                border-radius: 6px;
            }
            #presetButton {
                color: #ececf0;
                background: #151517;
                border: 1px solid #303036;
                border-radius: 5px;
                font-size: 12px;
                font-weight: 750;
                padding: 9px 12px;
            }
            #presetButton:hover {
                border-color: #ff5962;
                background: #1b181a;
            }
            #presetButton[selected="true"] {
                border-color: #ff4852;
                background: #231416;
                color: #ffffff;
            }
            #updateInlineCard {
                background: #141416;
                border: 1px solid #29292e;
                border-radius: 5px;
            }

            #guideStep {
                background: #171718;
                border: 1px solid #252528;
                border-radius: 4px;
            }

            #guideBadge {
                background: #ff454d;
                color: #ffffff;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 750;
            }

            #guideTitle {
                color: #eeeeef;
                font-size: 15px;
                font-weight: 650;
            }

            #guideBody {
                color: #9a9ba0;
                font-size: 13px;
                font-weight: 400;
                padding-left: 34px;
            }

            #guideNote {
                background: #101713;
                border: 1px solid #1b432d;
                border-left: 3px solid #28df70;
                border-radius: 3px;
                color: #9ca7a0;
                font-size: 12px;
                padding: 10px 12px;
            }

            QScrollBar:vertical {
                background: transparent;
                width: 7px;
                margin: 2px;
            }

            QScrollBar::handle:vertical {
                background: #303034;
                min-height: 30px;
                border-radius: 3px;
            }

            QScrollBar::handle:vertical:hover {
                background: #414146;
            }

            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

    def _load_ui_values(self):
        self._loading_ui = True
        s = self.settings

        self.scale_row.setValue(float(s["scale"]))
        self.width_row.setValue(float(s["width_factor"]))
        self.height_row.setValue(float(s["height_factor"]))
        self.opacity_row.setValue(float(s["opacity"]))
        self.history_row.setValue(float(s["history_seconds"]))
        if hasattr(self, "history_style_row"):
            self.history_style_row.setValue(str(s.get("history_style", "classic")))

        for key, row in self.element_rows.items():
            row.setChecked(bool(s[key]))

        self.always_row.setChecked(
            bool(s["always_on_top"])
        )
        self.lock_row.setChecked(
            bool(s["lock_position"])
        )
        self.auto_row.setChecked(
            bool(s.get("auto_activate_on_connect", False))
        )
        if hasattr(self, "arc_row"):
            self.arc_row.setChecked(bool(s.get("arc_mode", False)))
        if hasattr(self, "arc_intensity_row"):
            self.arc_intensity_row.setValue(float(s.get("arc_intensity", .50)))
        if hasattr(self, "arc_preview"):
            self.arc_preview.set_values(bool(s.get("arc_mode", False)), float(s.get("arc_intensity", .50)))
        if hasattr(self, "reduce_anim_row"):
            self.reduce_anim_row.setChecked(bool(s.get("reduce_animations", False)))
        if hasattr(self, "decorative_row"):
            self.decorative_row.setChecked(bool(s.get("decorative_effects", True)))
        self._sync_preset_ui()
        self._refresh_wheel_page()

        if hasattr(self, "preview"):
            self.preview.setSettings(self.settings)
        self._loading_ui = False

    def _set(self, key, value):
        self.settings[key] = value
        if key.startswith("show_") and not getattr(self, "_applying_preset", False) and not getattr(self, "_loading_ui", False):
            self.settings["preset_name"] = "custom"
            self._sync_preset_ui()
        self.overlay.apply_settings(self.settings)

        if hasattr(self, "preview"):
            self.preview.setSettings(self.settings)
        if key in ("arc_mode", "arc_intensity") and hasattr(self, "arc_preview"):
            self.arc_preview.set_values(bool(self.settings.get("arc_mode", False)), float(self.settings.get("arc_intensity", .50)))

        self._schedule_save()

    def _sync_preset_ui(self):
        name = str(self.settings.get("preset_name", "custom"))
        if hasattr(self, "preset_status"):
            labels = {"complete":"Preset ativo · Completo", "compact":"Preset ativo · Compacto", "minimal":"Preset ativo · Minimalista", "custom":"Configuração personalizada"}
            self.preset_status.setText(labels.get(name, "Configuração personalizada"))
        if hasattr(self, "preset_buttons"):
            for key, btn in self.preset_buttons.items():
                btn.setProperty("selected", key == name)
                btn.style().unpolish(btn); btn.style().polish(btn)

    def _apply_preset(self, name):
        presets = {
            "complete": {"show_history":True,"show_bars":True,"show_wheel":True,"show_info":True,"show_fuel":True,"show_active_aero":True},
            "compact": {"show_history":True,"show_bars":True,"show_wheel":False,"show_info":True,"show_fuel":False,"show_active_aero":False},
            "minimal": {"show_history":False,"show_bars":True,"show_wheel":False,"show_info":True,"show_fuel":False,"show_active_aero":False},
        }
        config = presets.get(name)
        if not config: return
        self._applying_preset = True
        try:
            self.settings.update(config)
            self.settings["preset_name"] = name
            for key, value in config.items():
                if key in self.element_rows:
                    self.element_rows[key].setChecked(value)
            self.overlay.apply_settings(self.settings)
            if hasattr(self,"preview"): self.preview.setSettings(self.settings)
            self._sync_preset_ui()
            self._schedule_save()
        finally:
            self._applying_preset = False

    def _set_arc_intensity(self, value):
        self.settings["arc_intensity"] = float(value)
        if hasattr(self,"arc_intensity_row"): self.arc_intensity_row.setValue(float(value))
        self.overlay.apply_settings(self.settings)
        if hasattr(self,"arc_preview"): self.arc_preview.set_values(bool(self.settings.get("arc_mode",False)), float(value))
        self._schedule_save()

    def _restore_arc(self):
        self.settings["arc_mode"] = False
        self.settings["arc_intensity"] = .50
        if hasattr(self,"arc_row"): self.arc_row.setChecked(False)
        if hasattr(self,"arc_intensity_row"): self.arc_intensity_row.setValue(.50)
        self.overlay.apply_settings(self.settings)
        if hasattr(self,"arc_preview"): self.arc_preview.set_values(False, .50)
        self._schedule_save()

    def _history_changed(self, value):
        self.settings["history_seconds"] = value
        core.HISTORY_SECONDS = value
        self._schedule_save()

    def _schedule_save(self):
        if hasattr(self, "save_timer"):
            self.save_timer.start(250)
        else:
            save_settings(self.settings)

    def _save_now(self):
        if self.overlay.isVisible():
            pos = self.overlay.pos()
            self.settings["pos_x"] = pos.x()
            self.settings["pos_y"] = pos.y()

        save_settings(self.settings)

    def _show_telemetry_activation_popup(self, active=True):
        try:
            if self._screen_activation_toast is not None:
                self._screen_activation_toast.close()
        except Exception:
            pass

        screen = QApplication.screenAt(self.overlay.frameGeometry().center())
        if screen is None:
            screen = QApplication.screenAt(self.frameGeometry().center())
        if screen is None:
            screen = QApplication.primaryScreen()

        self._screen_activation_toast = TelemetryScreenToast(
            screen=screen,
            active=bool(active),
            reduced_motion=bool(self.settings.get("reduce_animations", False)),
        )
        self._screen_activation_toast.present()

    def _toggle_overlay(self):
        # Use the saved activation state rather than QWidget.isVisible(), because
        # the closing animation intentionally keeps the window visible for ~0.6 s.
        enabled = not bool(self.settings.get("overlay_enabled", False))
        self.settings["overlay_enabled"] = enabled

        if enabled:
            self.overlay.apply_settings(self.settings)
            self.overlay.animated_show()
            self.overlay.raise_()
            QTimer.singleShot(140, lambda: self._show_telemetry_activation_popup(True))
        else:
            self._show_telemetry_activation_popup(False)
            self.overlay.animated_hide()

        self._sync_activation_ui()
        self._schedule_save()

    def _sync_activation_ui(self):
        active = bool(self.settings.get("overlay_enabled", False))

        if active:
            self.activate_btn.setText("DESATIVAR")
            self.activate_btn.setObjectName("activateOff")
            self.status_text.setText("STATUS  ·  ATIVA")
            self.status_banner.setObjectName("statusBannerActive")
        else:
            self.activate_btn.setText("ATIVAR")
            self.activate_btn.setObjectName("activateOn")
            self.status_text.setText("STATUS  ·  DESATIVADA")
            self.status_banner.setObjectName("statusBannerInactive")

        if hasattr(self, "nav_overlay"):
            self.nav_overlay.setOverlayActive(active)

        for widget in (self.activate_btn, self.status_banner, self.status_text):
            widget.style().unpolish(widget)
            widget.style().polish(widget)

    def _move_overlay(self):
        if not self.overlay.isVisible():
            self.overlay.animated_show()
            self.settings["overlay_enabled"] = True
            self._sync_activation_ui()

        self.settings["lock_position"] = False
        self.lock_row.setChecked(False)
        self.overlay.apply_settings(self.settings)
        self.overlay.raise_()

        self.move_btn.setText("ARRASTE A OVERLAY NA TELA")
        QTimer.singleShot(
            2400,
            lambda: self.move_btn.setText("MOVER OVERLAY")
        )

        self._schedule_save()

    def _center_overlay(self):
        screen = QApplication.screenAt(self.frameGeometry().center())
        if screen is None:
            screen = QApplication.primaryScreen()

        geo = screen.availableGeometry()
        x = geo.x() + (geo.width() - self.overlay.width()) // 2
        y = geo.y() + 28

        self.overlay.move(x, y)
        self.settings["pos_x"] = x
        self.settings["pos_y"] = y
        self._last_pos = (x, y)
        self._schedule_save()

    def _test_overlay(self):
        if self._test_running:
            return

        self._test_running = True
        self._test_restore_visible = self.overlay.isVisible()

        core.set_demo_mode(True)
        self.overlay.apply_settings(self.settings)
        self.overlay.animated_show()
        self.overlay.raise_()

        self.test_btn.setText("TESTE ATIVO · 8s")
        self.test_btn.setEnabled(False)

        QTimer.singleShot(8000, self._finish_overlay_test)

    def _finish_overlay_test(self):
        core.set_demo_mode(False)

        if not self._test_restore_visible:
            self.overlay.animated_hide()

        self._test_running = False
        self.test_btn.setEnabled(True)
        self.test_btn.setText("TESTAR OVERLAY")
        self._sync_activation_ui()

    def _export_settings(self):
        self._save_now()

        path, _ = QFileDialog.getSaveFileName(
            self,
            "Exportar configurações",
            "Zoltraak_Config.json",
            "Configuração Zoltraak (*.json)"
        )
        if not path:
            return

        if not path.lower().endswith(".json"):
            path += ".json"

        try:
            Path(path).write_text(
                json.dumps(self.settings, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
            QMessageBox.information(
                self,
                "Exportar configurações",
                "Configurações exportadas com sucesso."
            )
        except Exception as exc:
            QMessageBox.warning(
                self,
                "Exportar configurações",
                f"Não foi possível exportar o arquivo.\\n\\n{exc}"
            )

    def _import_settings(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Importar configurações",
            "",
            "Configuração Zoltraak (*.json)"
        )
        if not path:
            return

        try:
            loaded = json.loads(Path(path).read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise ValueError("Arquivo de configuração inválido.")

            imported = dict(DEFAULTS)
            for key in DEFAULTS:
                if key in loaded:
                    imported[key] = loaded[key]

            # Keep the current runtime active state; importing a layout should
            # not unexpectedly launch or hide the overlay.
            imported["overlay_enabled"] = self.overlay.isVisible()

            self.settings = imported
            core.HISTORY_SECONDS = float(self.settings["history_seconds"])
            self._load_ui_values()
            self.overlay.apply_settings(self.settings)

            if hasattr(self, "preview"):
                self.preview.setSettings(self.settings)

            self._sync_activation_ui()
            self._schedule_save()

            QMessageBox.information(
                self,
                "Importar configurações",
                "Configurações importadas com sucesso."
            )
        except Exception as exc:
            QMessageBox.warning(
                self,
                "Importar configurações",
                f"Não foi possível importar o arquivo.\\n\\n{exc}"
            )

    def _reset_defaults(self):
        answer = QMessageBox.question(
            self,
            "Restaurar tudo ao padrão",
            "Restaurar aparência, módulos, posição, volante visual, Modo Arco e demais preferências para o padrão?\n\nA introdução e o histórico de suporte não serão apagados.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )

        if answer != QMessageBox.Yes:
            return

        keep_enabled = bool(self.settings.get("overlay_enabled", False))

        self.settings = dict(DEFAULTS)
        self.settings["overlay_enabled"] = keep_enabled

        core.HISTORY_SECONDS = self.settings["history_seconds"]

        self._load_ui_values()
        self.overlay.apply_settings(self.settings)
        if hasattr(self, "preview"):
            self.preview.setSettings(self.settings)

        if keep_enabled:
            self.overlay.animated_show()

        self._sync_activation_ui()
        self._schedule_save()
        self._show_status_toast(
            "CONFIGURAÇÕES RESTAURADAS",
            "A overlay voltou aos ajustes padrão. Você pode personalizar tudo novamente a qualquer momento.",
            "#38d98a",
        )

    def _refresh_status(self):
        with core.state.lock:
            last = core.state.last_packet
            hz = core.state.telemetry_hz

        connected = (
            (time.monotonic() - last) < 1.5
            if last else False
        )

        if connected:
            self.connection_dot.setActive(True)
            rate = max(0, round(hz))
            self.connection_label.setText(
                f"F1 26 CONNECTED · {rate} Hz"
            )
            self.connection_label.setObjectName(
                "connectionLive"
            )
            if hasattr(self, "telemetry_health"):
                self.telemetry_health.setText(f"F1 CONNECTED  ·  UDP STABLE  ·  {rate} Hz")
                self.telemetry_health.setObjectName("telemetryHealthLive")
        else:
            self.connection_dot.setActive(False)
            self.connection_label.setText(
                "WAITING FOR F1"
            )
            self.connection_label.setObjectName(
                "connectionWait"
            )
            if hasattr(self, "telemetry_health"):
                self.telemetry_health.setText("F1 OFFLINE  ·  UDP -- Hz")
                self.telemetry_health.setObjectName("telemetryHealthWait")

        self.connection_label.style().unpolish(
            self.connection_label
        )
        self.connection_label.style().polish(
            self.connection_label
        )
        if hasattr(self, "telemetry_health"):
            self.telemetry_health.style().unpolish(self.telemetry_health)
            self.telemetry_health.style().polish(self.telemetry_health)

        # Auto-activate only on a new connection edge.
        if (
            connected
            and not self._was_connected
            and self.settings.get("auto_activate_on_connect", False)
            and not self.overlay.isVisible()
            and not self._test_running
        ):
            self.settings["overlay_enabled"] = True
            self.overlay.apply_settings(self.settings)
            self.overlay.animated_show()
            self.overlay.raise_()
            self._sync_activation_ui()
            self._schedule_save()
            QTimer.singleShot(140, lambda: self._show_telemetry_activation_popup(True))

        self._was_connected = connected

        if (
            self.overlay.isVisible()
            and not self.settings.get("lock_position", False)
        ):
            pos = self.overlay.pos()
            current = (pos.x(), pos.y())

            if current != self._last_pos:
                self._last_pos = current
                self.settings["pos_x"] = pos.x()
                self.settings["pos_y"] = pos.y()
                self._schedule_save()

    def _scroll_to_settings(self):
        bar = self.content_scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _show_support(self):
        QMessageBox.information(
            self,
            "Zoltraak Control",
            "Área de suporte ainda não configurada.\n\n"
            "Depois podemos colocar aqui um link do Discord "
            "ou uma página de ajuda."
        )

    def closeEvent(self, event):
        core.set_demo_mode(False)
        self._save_now()
        self.overlay.close()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Zoltraak Control")
    app.setStyle("Fusion")

    icon_file = resource_path("assets/zoltraak.ico")
    if icon_file.exists():
        app.setWindowIcon(QIcon(str(icon_file)))

    splash = StartupSplash()
    holder = {"window": None}

    def open_control():
        holder["window"] = ControlWindow()
        holder["window"].show()
        holder["window"].raise_()
        holder["window"].activateWindow()

    splash.finished.connect(open_control)
    splash.start()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
