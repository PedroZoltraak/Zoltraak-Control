import os
import sys
import json
import time
import uuid
import subprocess
import threading
import urllib.parse
import urllib.request
import urllib.error
import mimetypes
import hashlib
import re
import webbrowser
from pathlib import Path

from PySide6.QtCore import (
    Qt, QTimer, Signal, QObject, QPropertyAnimation, QEasingCurve,
    QUrl, QPointF, QRectF
)
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QPainterPath, QPixmap
from PySide6.QtWidgets import (
    QApplication, QDialog, QFrame, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QStackedWidget, QWidget, QScrollArea, QLineEdit, QTextEdit, QComboBox,
    QListWidget, QListWidgetItem, QCheckBox, QProgressBar, QMessageBox,
    QGraphicsOpacityEffect, QFileDialog
)
SUPPORT_API_URL = "https://zoltraak-support.pedrinhoosantiago2408.workers.dev/ticket"
REMOTE_PROFILE_CATALOG_URL = "https://raw.githubusercontent.com/PedroZoltraak/Zoltraak-Control/main/profiles/catalog.json"
REMOTE_PROFILE_BASE_URL = "https://raw.githubusercontent.com/PedroZoltraak/Zoltraak-Control/main/profiles/"

WHEEL_CATALOG = [
    ("Logitech", "G29", ["g29", "driving force"]),
    ("Logitech", "G920", ["g920"]),
    ("Logitech", "G923", ["g923"]),
    ("Logitech", "PRO Racing Wheel", ["pro racing wheel", "logitech pro"]),
    ("Thrustmaster", "T150", ["t150"]),
    ("Thrustmaster", "T248", ["t248"]),
    ("Thrustmaster", "T300 RS", ["t300"]),
    ("Thrustmaster", "T-GT II", ["t-gt", "tgt ii"]),
    ("Thrustmaster", "TS-XW", ["ts-xw", "tsxw"]),
    ("Fanatec", "CSL DD", ["csl dd"]),
    ("Fanatec", "Gran Turismo DD Pro", ["gt dd pro", "gran turismo dd pro"]),
    ("Fanatec", "ClubSport DD", ["clubsport dd"]),
    ("MOZA", "R3", ["moza r3"]),
    ("MOZA", "R5", ["moza r5"]),
    ("MOZA", "R9", ["moza r9"]),
    ("MOZA", "R12", ["moza r12"]),
    ("MOZA", "R16", ["moza r16"]),
    ("MOZA", "R21", ["moza r21"]),
    ("Simagic", "Alpha Mini", ["alpha mini", "simagic"]),
    ("Simagic", "Alpha", ["simagic alpha"]),
    ("Simucube", "2 Sport", ["simucube 2 sport"]),
    ("Simucube", "2 Pro", ["simucube 2 pro"]),
    ("Asetek", "La Prima", ["la prima", "asetek"]),
    ("Asetek", "Forte", ["asetek forte"]),
    ("Asetek", "Invicta", ["asetek invicta"]),
    ("PXN", "V10", ["pxn v10"]),
    ("PXN", "V12", ["pxn v12"]),
    ("HORI", "Racing Wheel Apex", ["racing wheel apex", "hori"]),
    ("Turtle Beach", "VelocityOne Race", ["velocityone race", "turtle beach"]),
    ("Cammus", "C5", ["cammus c5"]),
    ("Cammus", "C12", ["cammus c12"]),
]

# Visual wheel profiles are intentionally conservative: the Control can identify many
# devices, while a specific overlay visual is only marked available after a real profile
# has been created and tested. The default Zoltraak wheel is always available.
VISUAL_PROFILES = {
    "default": {
        "name": "Volante padrão Zoltraak",
        "description": "Perfil visual padrão incluído no Zoltraak Control.",
        "available": True,
    }
}


def app_data_dir():
    root = os.getenv("APPDATA")
    folder = Path(root) / "ZoltraakControl" if root else Path.home() / ".zoltraak_control"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def detect_wheels_local():
    """Best-effort local wheel/game-controller detection. No network calls."""
    if sys.platform != "win32":
        return []
    names = []
    # PowerShell gives us the friendly names exposed by Windows. We intentionally do
    # not read serial numbers or other unnecessary identifiers.
    cmd = [
        "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
        "Get-PnpDevice -PresentOnly | "
        "Where-Object { $_.FriendlyName -and ($_.Class -match 'HIDClass|MEDIA|System' -or $_.FriendlyName -match 'wheel|racing|logitech|thrustmaster|fanatec|moza|simagic|simucube|asetek|cammus|pxn|hori|turtle') } | "
        "Select-Object -ExpandProperty FriendlyName | ConvertTo-Json -Compress"
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=6, creationflags=0x08000000)
        raw = (result.stdout or "").strip()
        if raw:
            data = json.loads(raw)
            if isinstance(data, str):
                data = [data]
            for item in data or []:
                text = str(item).strip()
                low = text.lower()
                if any(k in low for k in (
                    "wheel", "racing", "g29", "g920", "g923", "logitech pro",
                    "t150", "t248", "t300", "t-gt", "ts-xw", "fanatec",
                    "moza", "simagic", "simucube", "asetek", "cammus", "pxn",
                    "hori", "velocityone"
                )):
                    names.append(text)
    except Exception:
        pass

    # De-duplicate preserving order.
    seen = set()
    output = []
    for name in names:
        key = name.casefold()
        if key not in seen:
            seen.add(key)
            output.append(name)
    return output[:12]


def match_catalog(device_name):
    low = str(device_name or "").lower()
    for brand, model, aliases in WHEEL_CATALOG:
        if any(alias in low for alias in aliases):
            return {
                "brand": brand,
                "model": model,
                "display": f"{brand} {model}",
                "profile_available": False,
                "profile_key": "default",
            }
    return None



def _multipart_body(fields, photo_path=None):
    boundary = "----ZoltraakControl" + uuid.uuid4().hex
    out = bytearray()
    def add_line(value=b""):
        if isinstance(value, str): value = value.encode("utf-8")
        out.extend(value + b"\r\n")
    for name, value in fields.items():
        add_line(f"--{boundary}")
        add_line(f'Content-Disposition: form-data; name="{name}"')
        add_line()
        add_line(str(value or ""))
    if photo_path:
        path = Path(photo_path)
        if path.exists() and path.is_file() and path.stat().st_size <= 5 * 1024 * 1024:
            mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            add_line(f"--{boundary}")
            add_line(f'Content-Disposition: form-data; name="photo"; filename="{path.name}"')
            add_line(f"Content-Type: {mime}")
            add_line()
            out.extend(path.read_bytes()); out.extend(b"\r\n")
    add_line(f"--{boundary}--")
    return boundary, bytes(out)


def send_support_ticket(brand, model, windows_name, note, version, photo_path=None):
    boundary, body = _multipart_body({
        "brand": brand,
        "model": model,
        "windows_name": windows_name,
        "note": note,
        "version": version,
    }, photo_path)
    req = urllib.request.Request(
        SUPPORT_API_URL,
        data=body,
        headers={
            "Content-Type": f"multipart/form-data; boundary={boundary}",
            "User-Agent": f"ZoltraakControl/{version}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=18) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        try: data = json.loads(exc.read().decode("utf-8", errors="replace"))
        except Exception: data = {"ok": False, "error": f"HTTP {exc.code}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return data if isinstance(data, dict) else {"ok": False, "error": "Resposta inválida do serviço."}


def fetch_remote_profile_catalog(timeout=8):
    req = urllib.request.Request(REMOTE_PROFILE_CATALOG_URL, headers={"User-Agent":"ZoltraakControl/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        if not isinstance(data, dict) or not isinstance(data.get("profiles", []), list):
            raise ValueError("Catálogo remoto inválido")
        return data
    except Exception:
        return {"schema_version": 1, "profiles": []}


def match_remote_profile(device_name, catalog):
    low = str(device_name or "").casefold()
    best = None
    for item in catalog.get("profiles", []):
        if not isinstance(item, dict) or not item.get("enabled", True):
            continue
        aliases = [str(x).casefold() for x in item.get("aliases", [])]
        if any(a and a in low for a in aliases):
            best = item; break
    return best


def install_remote_profile(profile):
    key = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(profile.get("key", "profile"))).strip("_") or "profile"
    image_rel = str(profile.get("image", "")).lstrip("/")
    if not image_rel or ".." in image_rel:
        raise ValueError("Caminho de imagem inválido")
    url = REMOTE_PROFILE_BASE_URL + urllib.parse.quote(image_rel, safe="/._-")
    req = urllib.request.Request(url, headers={"User-Agent":"ZoltraakControl/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read(6 * 1024 * 1024)
    if not raw or len(raw) > 5 * 1024 * 1024:
        raise ValueError("Imagem de perfil inválida ou muito grande")
    expected = str(profile.get("sha256", "")).strip().lower()
    actual = hashlib.sha256(raw).hexdigest()
    if expected and expected != actual:
        raise ValueError("Falha de integridade do perfil")
    ext = Path(image_rel).suffix.lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp"):
        raise ValueError("Formato de imagem não suportado")
    folder = app_data_dir() / "profiles"
    folder.mkdir(parents=True, exist_ok=True)
    image_path = folder / f"{key}{ext}"
    image_path.write_bytes(raw)
    meta = dict(profile); meta["installed_image"] = str(image_path); meta["installed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    (folder / f"{key}.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return meta



class WheelScanWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.phase = 0.0
        self.setMinimumHeight(170)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._step)
        self.timer.start(25)

    def _step(self):
        self.phase = (self.phase + .018) % 1.0
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        cx, cy = self.width()/2, self.height()/2 + 5
        # subtle rings
        p.setPen(QPen(QColor(50, 56, 68, 120), 1))
        for r in (54, 72):
            p.drawEllipse(QPointF(cx, cy), r, r)

        path = QPainterPath()
        path.moveTo(cx-70, cy-4)
        path.cubicTo(cx-62, cy-52, cx-42, cy-60, cx-24, cy-52)
        path.lineTo(cx+24, cy-52)
        path.cubicTo(cx+42, cy-60, cx+62, cy-52, cx+70, cy-4)
        path.cubicTo(cx+72, cy+35, cx+56, cy+56, cx+34, cy+48)
        path.lineTo(cx+21, cy+26)
        path.lineTo(cx-21, cy+26)
        path.lineTo(cx-34, cy+48)
        path.cubicTo(cx-56, cy+56, cx-72, cy+35, cx-70, cy-4)
        p.setBrush(QColor(10, 12, 17, 230))
        p.setPen(QPen(QColor("#cfd5df"), 3))
        p.drawPath(path)

        # scan arc / energy point
        angle = self.phase * 6.2831853
        x = cx + 72 * __import__("math").cos(angle)
        y = cy + 72 * __import__("math").sin(angle)
        p.setPen(QPen(QColor(255, 65, 76, 100), 5))
        p.drawArc(QRectF(cx-74, cy-74, 148, 148), int(-self.phase*360*16), 62*16)
        p.setBrush(QColor("#ff4652"))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(x, y), 4, 4)


DIALOG_STYLE = """
    QDialog { background: transparent; }
    #panel { background:#101012; border:1px solid #34343a; border-radius:8px; }
    #kicker { color:#ff5a63; font-size:10px; font-weight:800; letter-spacing:1px; }
    #title { color:#f4f4f6; font-size:28px; font-weight:750; }
    #subtitle { color:#94969d; font-size:13px; }
    #body { color:#a9abb2; font-size:13px; }
    #muted { color:#696b73; font-size:11px; }
    #card { background:#171719; border:1px solid #29292e; border-radius:6px; }
    #card[status="ok"] { background:#0f1b15; border:1px solid #245f3b; }
    #kicker[status="ok"] { color:#4bec8a; }
    #body[status="ok"] { color:#b9f6ce; }
    #cardTitle { color:#ededf0; font-size:14px; font-weight:700; }
    #primary { color:white; background:#ff4852; border:1px solid #ff4852; border-radius:4px; padding:10px 18px; font-weight:800; }
    #primary:hover { background:#ff5a63; }
    #secondary { color:#e9e9eb; background:#1a1a1d; border:1px solid #38383e; border-radius:4px; padding:9px 16px; font-weight:700; }
    #secondary:hover { background:#232327; }
    #ghost { color:#9d9fa7; background:transparent; border:1px solid #323238; border-radius:4px; padding:9px 16px; }
    QLineEdit, QTextEdit, QComboBox, QListWidget { background:#111216; border:1px solid #303139; border-radius:4px; color:#e8e8ea; padding:7px; }
    QProgressBar { background:#1a1b20; border:none; border-radius:2px; height:4px; text-align:center; color:transparent; }
    QProgressBar::chunk { background:#ff4852; border-radius:2px; }
    QScrollArea { border:none; background:transparent; }
    QScrollBar:vertical { background:transparent; width:6px; }
    QScrollBar::handle:vertical { background:#37383e; min-height:28px; border-radius:3px; }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
"""


class OnboardingDialog(QDialog):
    """Five-step first-run onboarding. ESC/close are intentionally blocked."""
    def __init__(self, version, verify_updates_callback=None, resource_resolver=None, parent=None):
        super().__init__(parent)
        self.version = version
        self.verify_updates_callback = verify_updates_callback
        self.resource_resolver = resource_resolver
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(820, 650)
        self.page_index = 0

        panel = QFrame(self)
        panel.setObjectName("panel")
        panel.setGeometry(0, 0, self.width(), self.height())
        root = QVBoxLayout(panel)
        root.setContentsMargins(30, 25, 30, 24)
        root.setSpacing(12)

        top = QHBoxLayout()
        logo = QLabel("ZOLTRAAK CONTROL TELEMETRY")
        logo.setObjectName("kicker")
        badge = QLabel(f"PRIMEIRA CONFIGURAÇÃO · v{version}")
        badge.setObjectName("muted")
        top.addWidget(logo)
        top.addStretch()
        top.addWidget(badge)
        root.addLayout(top)

        self.stack = QStackedWidget()
        pages = [
            (
                "01 · BOAS-VINDAS", "Bem-vindo ao Zoltraak Control",
                "Obrigado por instalar o Zoltraak Control Telemetry. Antes de começar, queremos apresentar rapidamente o projeto e mostrar como configurar sua overlay corretamente.",
                ["Projeto pessoal", "F1 26", "Configuração rápida"]
            ),
            (
                "02 · SOBRE O PROJETO", "Um projeto pessoal e independente",
                "O Zoltraak Control Telemetry foi criado inicialmente para uso próprio e posteriormente disponibilizado gratuitamente para outras pessoas testarem. O projeto continua em desenvolvimento e poderá receber correções, melhorias e novas funcionalidades com o tempo.\n\nNão é um produto profissional ou comercial.",
                ["Gratuito para testar", "Em desenvolvimento", "Independente"]
            ),
            (
                "03 · PROPOSTA", "Uma telemetria criada para uma necessidade específica",
                "O Zoltraak Control não foi criado para ser uma plataforma completa de telemetria profissional ou competitiva. Ele nasceu porque eu queria uma overlay de telemetria dos pedais para o F1 26, inspirada na forma como algumas informações são apresentadas no iRacing.\n\nNão encontrei uma opção gratuita com exatamente o visual e funcionamento que procurava; as alternativas mais próximas eram pagas. Foi daí que nasceu a overlay e, depois, o Control para configurá-la e compartilhá-la.",
                ["Pedal telemetry", "Inputs em tempo real", "Foco no essencial"]
            ),
            (
                "04 · OBRIGADO", "Obrigado por dar uma oportunidade ao projeto",
                "Obrigado por instalar e testar o Zoltraak Control Telemetry. Este projeto começou como uma solução pessoal e só chegou até aqui porque outras pessoas também demonstraram interesse.\n\nSeu feedback poderá ajudar a melhorar as próximas versões. Espero que a overlay seja útil para você e torne sua experiência no F1 26 ainda melhor.",
                ["Feedback é bem-vindo", "Melhorias contínuas"]
            ),
        ]
        for kicker, title, body, chips in pages:
            self.stack.addWidget(self._make_text_page(kicker, title, body, chips))
        self.stack.addWidget(self._make_usage_page())
        root.addWidget(self.stack, 1)

        nav = QHBoxLayout()
        self.progress_text = QLabel("1 de 5")
        self.progress_text.setObjectName("muted")
        self.progress = QProgressBar()
        self.progress.setRange(0, 5)
        self.progress.setValue(1)
        self.progress.setFixedWidth(180)
        self.back = QPushButton("ANTERIOR")
        self.back.setObjectName("secondary")
        self.back.clicked.connect(self._prev)
        self.next = QPushButton("CONTINUAR")
        self.next.setObjectName("primary")
        self.next.clicked.connect(self._next)
        nav.addWidget(self.progress_text)
        nav.addWidget(self.progress)
        nav.addStretch()
        nav.addWidget(self.back)
        nav.addWidget(self.next)
        root.addLayout(nav)
        self._sync_nav()
        self.setStyleSheet(DIALOG_STYLE)

    def _make_text_page(self, kicker, title, body, chips):
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(4, 15, 4, 8)
        lay.setSpacing(14)
        k = QLabel(kicker); k.setObjectName("kicker")
        t = QLabel(title); t.setObjectName("title"); t.setWordWrap(True)
        b = QLabel(body); b.setObjectName("body"); b.setWordWrap(True)
        lay.addWidget(k); lay.addWidget(t); lay.addWidget(b)
        lay.addSpacing(10)
        chip_row = QHBoxLayout(); chip_row.setSpacing(8)
        for text in chips:
            c = QLabel(text.upper()); c.setObjectName("muted")
            c.setStyleSheet("background:#17181c;border:1px solid #2d2e34;border-radius:12px;padding:6px 10px;")
            chip_row.addWidget(c)
        chip_row.addStretch()
        lay.addLayout(chip_row)
        lay.addStretch()
        return page

    def _make_usage_page(self):
        page = QWidget()
        lay = QVBoxLayout(page); lay.setContentsMargins(4, 10, 4, 4); lay.setSpacing(10)
        k = QLabel("05 · COMO UTILIZAR"); k.setObjectName("kicker")
        t = QLabel("Pronto para colocar a overlay na pista"); t.setObjectName("title")
        lay.addWidget(k); lay.addWidget(t)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        content = QWidget(); v = QVBoxLayout(content); v.setContentsMargins(0,0,4,0); v.setSpacing(7)
        steps = [
            "Abra o F1 26 e ative a telemetria UDP.",
            "Use IP 127.0.0.1 e porta UDP 20777.",
            "Selecione o formato de telemetria 2026 e frequência de 60 Hz.",
            "Abra o Zoltraak Control e clique em ATIVAR.",
            "Use F6 para movimentar a overlay e F7 para ativar/desativar rapidamente.",
            "Ajuste escala, largura, altura, opacidade e módulos.",
            "Em Volante & Perfis você pode detectar seu dispositivo e voltar ao volante padrão quando quiser.",
        ]
        for i, text in enumerate(steps, 1):
            card = QFrame(); card.setObjectName("card")
            row = QHBoxLayout(card); row.setContentsMargins(12,9,12,9)
            n = QLabel(f"{i:02d}"); n.setObjectName("kicker"); n.setFixedWidth(28)
            txt = QLabel(text); txt.setObjectName("body"); txt.setWordWrap(True)
            row.addWidget(n); row.addWidget(txt, 1); v.addWidget(card)
        warn = QLabel("IMPORTANTE · Sempre verifique manualmente se existem atualizações disponíveis. A verificação automática pode falhar ocasionalmente por conexão ou indisponibilidade do serviço.")
        warn.setObjectName("body"); warn.setWordWrap(True)
        warn.setStyleSheet("background:#211718;border:1px solid #5f2b31;border-radius:5px;padding:10px;color:#ffc0c4;")
        v.addWidget(warn)
        verify = QPushButton("VERIFICAR ATUALIZAÇÕES")
        verify.setObjectName("secondary")
        verify.clicked.connect(self._verify_updates)
        v.addWidget(verify, 0, Qt.AlignLeft)
        v.addStretch(); scroll.setWidget(content); lay.addWidget(scroll,1)
        return page

    def _verify_updates(self):
        if self.verify_updates_callback:
            try: self.verify_updates_callback()
            except Exception: pass

    def _prev(self):
        if self.page_index > 0:
            self.page_index -= 1; self._switch()

    def _next(self):
        if self.page_index < 4:
            self.page_index += 1; self._switch()
        else:
            self.accept()

    def _switch(self):
        self.stack.setCurrentIndex(self.page_index)
        self._sync_nav()
        current = self.stack.currentWidget()
        effect = QGraphicsOpacityEffect(current)
        current.setGraphicsEffect(effect)
        self._page_anim = QPropertyAnimation(effect, b"opacity", self)
        self._page_anim.setDuration(210)
        self._page_anim.setStartValue(0.20)
        self._page_anim.setEndValue(1.0)
        self._page_anim.setEasingCurve(QEasingCurve.OutCubic)
        self._page_anim.finished.connect(lambda w=current: w.setGraphicsEffect(None))
        self._page_anim.start()

    def _sync_nav(self):
        self.progress_text.setText(f"{self.page_index+1} de 5")
        self.progress.setValue(self.page_index+1)
        self.back.setEnabled(self.page_index > 0)
        self.next.setText("CONCLUIR" if self.page_index == 4 else "CONTINUAR")

    def reject(self):
        # Onboarding is deliberately non-dismissible until the final step.
        return

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            event.ignore(); return
        super().keyPressEvent(event)


class WheelDetectionDialog(QDialog):
    choiceMade = Signal(str, str)  # action, device name
    scanReady = Signal(object)
    def __init__(self, detected_names=None, parent=None):
        super().__init__(parent)
        self.detected_names = [] if detected_names is None else list(detected_names or [])
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(700, 575)
        panel = QFrame(self); panel.setObjectName("panel"); panel.setGeometry(0,0,self.width(),self.height())
        lay = QVBoxLayout(panel); lay.setContentsMargins(28,24,28,24); lay.setSpacing(10)
        top = QHBoxLayout()
        k=QLabel("VOLANTE & PERFIS"); k.setObjectName("kicker")
        close_top = QPushButton("×"); close_top.setObjectName("ghost"); close_top.setFixedSize(36,30); close_top.setToolTip("Fechar"); close_top.clicked.connect(self._close_without_change)
        top.addWidget(k); top.addStretch(); top.addWidget(close_top); lay.addLayout(top)
        self.title=QLabel("Procurando dispositivos conectados…"); self.title.setObjectName("title")
        self.subtitle=QLabel("A detecção acontece localmente usando informações disponibilizadas pelo Windows."); self.subtitle.setObjectName("subtitle"); self.subtitle.setWordWrap(True)
        lay.addWidget(self.title); lay.addWidget(self.subtitle)
        self.scan=WheelScanWidget(); lay.addWidget(self.scan)
        self.result_card=QFrame(); self.result_card.setObjectName("card")
        rv=QVBoxLayout(self.result_card); rv.setContentsMargins(14,12,14,12); rv.setSpacing(5)
        self.result_title=QLabel("AGUARDANDO DETECÇÃO"); self.result_title.setObjectName("kicker")
        self.result_body=QLabel("Consultando os dispositivos conectados ao Windows…"); self.result_body.setObjectName("body"); self.result_body.setWordWrap(True)
        rv.addWidget(self.result_title); rv.addWidget(self.result_body); lay.addWidget(self.result_card)
        privacy=QLabel("Privacidade: a detecção normal não envia dados pessoais nem usa serviços externos. Uma solicitação de novo perfil só usa a internet depois da sua confirmação.")
        privacy.setObjectName("muted"); privacy.setWordWrap(True); lay.addWidget(privacy)
        buttons=QHBoxLayout()
        close_btn=QPushButton("FECHAR"); close_btn.setObjectName("ghost"); close_btn.clicked.connect(self._close_without_change)
        buttons.addWidget(close_btn); buttons.addStretch()
        self.default_btn=QPushButton("MANTER VOLANTE PADRÃO"); self.default_btn.setObjectName("secondary"); self.default_btn.clicked.connect(self._keep_default)
        self.activate_btn=QPushButton("ATIVAR ESTE VOLANTE"); self.activate_btn.setObjectName("primary"); self.activate_btn.clicked.connect(self._activate)
        self.activate_btn.hide()
        self.conclude_btn=QPushButton("CONCLUIR"); self.conclude_btn.setObjectName("primary"); self.conclude_btn.clicked.connect(self._keep_default); self.conclude_btn.hide()
        buttons.addWidget(self.default_btn); buttons.addWidget(self.activate_btn); buttons.addWidget(self.conclude_btn); lay.addLayout(buttons)
        self.setStyleSheet(DIALOG_STYLE)
        self.scanReady.connect(self._receive_scan)
        if detected_names is None:
            threading.Thread(target=self._scan_worker, daemon=True).start()
        else:
            QTimer.singleShot(850, self._finish_scan)

    def _scan_worker(self):
        self.scanReady.emit(detect_wheels_local())

    def _receive_scan(self, names):
        self.detected_names = list(names or [])
        QTimer.singleShot(300, self._finish_scan)

    def _finish_scan(self):
        if not self.detected_names:
            self.title.setText("Nenhum volante compatível identificado")
            self.result_title.setText("AGUARDANDO DETECÇÃO")
            self.result_body.setText("Nenhum dispositivo com nome reconhecível foi encontrado. Você poderá usar o volante padrão e abrir o assistente ‘Meu volante não aparece’ depois.")
            return
        name = self.detected_names[0]
        match = match_catalog(name)
        self.title.setText("Volante detectado com sucesso")
        self.result_card.setProperty("status", "ok")
        self.result_title.setProperty("status", "ok")
        self.result_body.setProperty("status", "ok")
        if match:
            self.result_title.setText("VOLANTE DETECTADO")
            self.result_body.setText(f"{match['display']}\nReconhecido pelo Windows com sucesso.\nVisual atual: volante padrão Zoltraak.")
        else:
            self.result_title.setText("VOLANTE DETECTADO")
            self.result_body.setText(f"{name}\nReconhecido pelo Windows com sucesso.\nVisual atual: volante padrão Zoltraak.")
        for widget in (self.result_card, self.result_title, self.result_body):
            widget.style().unpolish(widget); widget.style().polish(widget)
        self.default_btn.hide()
        self.conclude_btn.show()

    def _close_without_change(self):
        QDialog.reject(self)

    def _keep_default(self):
        device = self.detected_names[0] if self.detected_names else ""
        self.choiceMade.emit("default", device); self.accept()

    def _activate(self):
        device = self.detected_names[0] if self.detected_names else ""
        self.choiceMade.emit("activate", device); self.accept()

    def reject(self):
        # The user must never be trapped in the detector. Closing keeps the current choice.
        QDialog.reject(self)


class WheelCompatibilityDialog(QDialog):
    """Fast profile request: brand + model + optional photo/observation."""
    ticketSent = Signal(dict)
    sendFinished = Signal(dict)

    def __init__(self, control_version, detected_name="", parent=None):
        super().__init__(parent)
        self.control_version = control_version
        self.detected_name = detected_name
        self.photo_path = ""
        self._sending = False
        self.setModal(True)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(720, 590)
        panel=QFrame(self); panel.setObjectName("panel"); panel.setGeometry(0,0,self.width(),self.height())
        root=QVBoxLayout(panel); root.setContentsMargins(28,24,28,24); root.setSpacing(11)
        top=QHBoxLayout(); k=QLabel("SOLICITAR PERFIL DE VOLANTE"); k.setObjectName("kicker")
        close=QPushButton("×"); close.setObjectName("ghost"); close.setFixedSize(34,30); close.clicked.connect(self.reject)
        top.addWidget(k); top.addStretch(); top.addWidget(close); root.addLayout(top)
        title=QLabel("Seu volante ainda não tem um perfil visual?"); title.setObjectName("title"); title.setWordWrap(True); root.addWidget(title)
        sub=QLabel("Informe a marca e o modelo. A solicitação chega diretamente ao responsável pelo projeto — sem GitHub, sem login e sem criar conta.")
        sub.setObjectName("subtitle"); sub.setWordWrap(True); root.addWidget(sub)

        card=QFrame(); card.setObjectName("card"); form=QVBoxLayout(card); form.setContentsMargins(16,14,16,14); form.setSpacing(9)
        self.brand=QLineEdit(); self.brand.setPlaceholderText("Marca *  — ex.: Logitech, MOZA, Fanatec")
        self.model=QLineEdit(); self.model.setPlaceholderText("Modelo completo *  — ex.: G923")
        self.windows_name=QLineEdit(self.detected_name); self.windows_name.setPlaceholderText("Nome detectado pelo Windows (automático quando disponível)")
        self.windows_name.setReadOnly(True)
        self.note=QTextEdit(); self.note.setPlaceholderText("Observação opcional — conte rapidamente o que aconteceu"); self.note.setFixedHeight(90)
        for w in (self.brand,self.model,self.windows_name,self.note): form.addWidget(w)
        photo_row=QHBoxLayout(); self.photo_label=QLabel("Imagem opcional · nenhuma selecionada"); self.photo_label.setObjectName("muted")
        photo_btn=QPushButton("ESCOLHER IMAGEM"); photo_btn.setObjectName("secondary"); photo_btn.clicked.connect(self._choose_photo)
        clear_btn=QPushButton("REMOVER"); clear_btn.setObjectName("ghost"); clear_btn.clicked.connect(self._clear_photo)
        photo_row.addWidget(self.photo_label,1); photo_row.addWidget(photo_btn); photo_row.addWidget(clear_btn); form.addLayout(photo_row)
        hint=QLabel("PNG/JPG/WEBP · até 5 MB. A foto é opcional e serve apenas como referência para preparar o desenho correto.")
        hint.setObjectName("muted"); hint.setWordWrap(True); form.addWidget(hint)
        root.addWidget(card)

        self.state=QLabel("Preencha os campos obrigatórios e clique em Enviar solicitação."); self.state.setObjectName("body"); self.state.setWordWrap(True); root.addWidget(self.state)
        privacy=QLabel("Privacidade · o envio contém somente os campos acima e a versão do Control. Nenhum número de série é coletado.")
        privacy.setObjectName("muted"); privacy.setWordWrap(True); root.addWidget(privacy)
        actions=QHBoxLayout(); cancel=QPushButton("CANCELAR"); cancel.setObjectName("secondary"); cancel.clicked.connect(self.reject)
        self.send_btn=QPushButton("ENVIAR SOLICITAÇÃO"); self.send_btn.setObjectName("primary"); self.send_btn.clicked.connect(self._send)
        actions.addWidget(cancel); actions.addStretch(); actions.addWidget(self.send_btn); root.addLayout(actions)
        self.sendFinished.connect(self._finish_send)
        self.setStyleSheet(DIALOG_STYLE)

    def _choose_photo(self):
        path,_=QFileDialog.getOpenFileName(self,"Escolher imagem do volante","","Imagens (*.png *.jpg *.jpeg *.webp)")
        if not path: return
        try:
            if Path(path).stat().st_size > 5*1024*1024:
                QMessageBox.warning(self,"Imagem muito grande","Escolha uma imagem de até 5 MB."); return
        except Exception: return
        self.photo_path=path; self.photo_label.setText(f"Imagem · {Path(path).name}")

    def _clear_photo(self):
        self.photo_path=""; self.photo_label.setText("Imagem opcional · nenhuma selecionada")

    def _send(self):
        brand=self.brand.text().strip(); model=self.model.text().strip()
        if not brand or not model:
            QMessageBox.warning(self,"Campos obrigatórios","Informe a marca e o modelo completo do volante."); return
        if self._sending: return
        self._sending=True; self.send_btn.setEnabled(False); self.send_btn.setText("ENVIANDO…")
        self.state.setText("Enviando sua solicitação com segurança…")
        data=(brand,model,self.windows_name.text().strip(),self.note.toPlainText().strip(),self.control_version,self.photo_path)
        def worker():
            result=send_support_ticket(*data)
            self.sendFinished.emit(result)
        threading.Thread(target=worker,daemon=True).start()

    def _finish_send(self,result):
        self._sending=False; self.send_btn.setEnabled(True); self.send_btn.setText("ENVIAR SOLICITAÇÃO")
        if not result.get("ok"):
            self.state.setText("Não foi possível enviar agora. Verifique sua internet e tente novamente.")
            QMessageBox.warning(self,"Falha no envio",f"Não foi possível enviar a solicitação.\n\n{result.get('error','Erro desconhecido')}")
            return
        ticket=str(result.get("ticket","ZCT-00000000"))
        QApplication.clipboard().setText(ticket)
        self.ticketSent.emit(result)
        done=QDialog(self); done.setModal(True); done.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint); done.setAttribute(Qt.WA_TranslucentBackground,True); done.setFixedSize(620,470)
        panel=QFrame(done); panel.setObjectName("panel"); panel.setGeometry(0,0,620,470); lay=QVBoxLayout(panel); lay.setContentsMargins(30,26,30,26); lay.setSpacing(12)
        k=QLabel("✓ SOLICITAÇÃO ENVIADA"); k.setObjectName("kicker"); k.setProperty("status","ok"); lay.addWidget(k)
        t=QLabel("Obrigado por informar seu volante."); t.setObjectName("title"); lay.addWidget(t)
        body=QLabel(
            "A solicitação chegou diretamente para mim e será analisada pessoalmente. Vou verificar o modelo e, quando possível, preparar e testar um perfil visual compatível para a overlay.\n\n"
            "Cada perfil precisa de recorte, proporção, ponto de rotação e testes antes de ser publicado. Por isso, o processo pode levar algum tempo.\n\n"
            "Prazo estimado: de 3 dias a 1 semana. O prazo é uma estimativa e não garante disponibilidade imediata. Enquanto isso, você pode continuar usando normalmente o Volante Padrão Zoltraak.\n\n"
            "Quando um perfil aprovado estiver disponível no catálogo online, o Control poderá baixá-lo sem exigir uma atualização completa do programa."
        ); body.setObjectName("body"); body.setWordWrap(True); lay.addWidget(body)
        tl=QLabel(f"Ticket · {ticket}"); tl.setObjectName("kicker"); lay.addWidget(tl)
        row=QHBoxLayout(); copy=QPushButton("COPIAR TICKET"); copy.setObjectName("secondary"); copy.clicked.connect(lambda: QApplication.clipboard().setText(ticket)); ok=QPushButton("CONCLUIR"); ok.setObjectName("primary"); ok.clicked.connect(done.accept); row.addWidget(copy); row.addStretch(); row.addWidget(ok); lay.addLayout(row)
        done.setStyleSheet(DIALOG_STYLE); done.exec(); self.accept()

    def reject(self):
        if self._sending: return
        super().reject()


class ArcControlPreview(QWidget):
    """Live preview of the same arc intensity applied to the real overlay."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.enabled = False
        self.intensity = .5
        self.phase = 0.0
        self.setFixedHeight(86)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(35)

    def set_values(self, enabled, intensity):
        self.enabled = bool(enabled)
        self.intensity = max(0.0, min(1.0, float(intensity)))
        self.update()

    def _tick(self):
        self.phase = (self.phase + .02) % 1.0
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self.rect().adjusted(8, 8, -8, -8)
        p.setPen(QPen(QColor("#272a31"), 1))
        p.setBrush(QColor("#0c0e12"))
        p.drawRoundedRect(r, 5, 5)
        left, right = r.left()+28, r.right()-28
        mid = r.center().y()+9
        curve = 24*self.intensity if self.enabled else 0
        path = QPainterPath()
        path.moveTo(left, mid)
        path.cubicTo(left+(right-left)*.28, mid-curve, left+(right-left)*.72, mid-curve, right, mid)
        p.setPen(QPen(QColor("#ff5360") if self.enabled else QColor("#676a73"), 2.2, Qt.SolidLine, Qt.RoundCap))
        p.drawPath(path)
        # moving highlight communicates that this is a live preview, not the rendering algorithm itself
        if self.enabled:
            x = left + (right-left)*self.phase
            import math
            y = mid - curve * math.sin(math.pi*self.phase)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#8c7cff"))
            p.drawEllipse(QPointF(x,y),3.2,3.2)
        p.setPen(QPen(QColor("#777b85"),1))
        p.drawText(r.adjusted(10,0,-10,0), Qt.AlignRight|Qt.AlignVCenter,
                   f"ARC {round(self.intensity*100)}%" if self.enabled else "ARC OFF")
